-- MariaDB dump 10.19  Distrib 10.4.32-MariaDB, for Win64 (AMD64)
--
-- Host: localhost    Database: seguridad_haydee_db
-- ------------------------------------------------------
-- Server version	10.4.32-MariaDB-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `asignacion_permisos`
--

DROP TABLE IF EXISTS `asignacion_permisos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `asignacion_permisos` (
  `rol_id` int(11) NOT NULL,
  `permiso_id` int(11) NOT NULL,
  `modulo_id` int(11) NOT NULL,
  PRIMARY KEY (`rol_id`,`permiso_id`,`modulo_id`) USING BTREE,
  KEY `asignacion_permisos_ibfk_1` (`modulo_id`),
  KEY `asignacion_permisos_ibfk_2` (`permiso_id`),
  CONSTRAINT `asignacion_permisos_ibfk_1` FOREIGN KEY (`modulo_id`) REFERENCES `modulos` (`id_modulo`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `asignacion_permisos_ibfk_2` FOREIGN KEY (`permiso_id`) REFERENCES `permisos` (`id_permiso`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `asignacion_permisos_ibfk_3` FOREIGN KEY (`rol_id`) REFERENCES `roles` (`id_rol`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `asignacion_permisos`
--

LOCK TABLES `asignacion_permisos` WRITE;
/*!40000 ALTER TABLE `asignacion_permisos` DISABLE KEYS */;
INSERT INTO `asignacion_permisos` VALUES (1,1,1),(1,1,2),(1,1,3),(1,1,4),(1,1,5),(1,1,6),(1,1,7),(1,1,8),(1,1,9),(1,1,10),(1,1,11),(1,1,12),(1,1,13),(1,1,14),(1,1,15),(1,1,16),(1,1,17),(1,1,18),(1,1,19),(1,1,21),(1,1,22),(1,1,23),(1,2,1),(1,2,2),(1,2,3),(1,2,4),(1,2,5),(1,2,6),(1,2,7),(1,2,8),(1,2,9),(1,2,10),(1,2,11),(1,2,12),(1,2,13),(1,2,14),(1,2,15),(1,2,16),(1,2,17),(1,2,18),(1,2,19),(1,2,21),(1,2,22),(1,2,23),(1,3,1),(1,3,2),(1,3,3),(1,3,4),(1,3,5),(1,3,6),(1,3,7),(1,3,8),(1,3,9),(1,3,10),(1,3,11),(1,3,12),(1,3,13),(1,3,14),(1,3,15),(1,3,16),(1,3,17),(1,3,18),(1,3,19),(1,3,21),(1,3,22),(1,3,23),(1,4,1),(1,4,2),(1,4,3),(1,4,4),(1,4,5),(1,4,6),(1,4,7),(1,4,8),(1,4,9),(1,4,10),(1,4,11),(1,4,12),(1,4,13),(1,4,14),(1,4,15),(1,4,16),(1,4,17),(1,4,18),(1,4,19),(1,4,21),(1,4,22),(1,4,23),(2,1,1),(2,1,2),(2,1,3),(2,1,4),(2,1,5),(2,1,6),(2,1,7),(2,1,8),(2,1,9),(2,1,10),(2,1,11),(2,1,12),(2,1,13),(2,1,14),(2,1,15),(2,1,16),(2,1,17),(2,1,18),(2,1,19),(2,1,21),(2,1,22),(2,1,23),(2,2,1),(2,2,2),(2,2,3),(2,2,4),(2,2,5),(2,2,6),(2,2,7),(2,2,8),(2,2,9),(2,2,10),(2,2,11),(2,2,12),(2,2,13),(2,2,14),(2,2,15),(2,2,16),(2,2,17),(2,2,18),(2,2,19),(2,2,21),(2,2,22),(2,2,23),(2,3,1),(2,3,2),(2,3,3),(2,3,4),(2,3,5),(2,3,6),(2,3,7),(2,3,8),(2,3,9),(2,3,10),(2,3,11),(2,3,12),(2,3,13),(2,3,14),(2,3,15),(2,3,16),(2,3,17),(2,3,18),(2,3,19),(2,3,21),(2,3,22),(2,3,23),(2,4,1),(2,4,2),(2,4,3),(2,4,4),(2,4,5),(2,4,6),(2,4,7),(2,4,8),(2,4,9),(2,4,10),(2,4,11),(2,4,12),(2,4,13),(2,4,14),(2,4,15),(2,4,16),(2,4,17),(2,4,18),(2,4,19),(2,4,21),(2,4,22),(2,4,23),(3,1,1),(3,2,1),(3,2,5),(3,3,1),(3,4,1),(4,1,1),(4,1,2),(4,1,3),(4,1,4),(4,1,5),(4,1,15),(4,2,1),(4,2,2),(4,2,3),(4,2,4),(4,2,5),(4,2,15),(4,3,1),(4,3,2),(4,3,3),(4,3,4),(4,3,5),(4,3,15),(4,4,1),(4,4,2),(4,4,3),(4,4,4),(4,4,5),(4,4,15),(69,2,1),(69,2,2),(69,2,3),(69,2,4),(69,2,5),(69,2,6),(69,2,7),(69,2,8),(69,2,9),(69,2,10),(69,2,11),(69,2,12),(69,2,13),(69,2,14),(69,2,15),(69,2,16),(69,2,17),(69,2,18),(69,2,19),(69,2,21),(69,2,22),(69,2,23),(70,1,1),(70,1,2),(70,2,1),(70,2,2),(70,3,1),(70,3,2),(70,4,1),(70,4,2),(71,1,19),(71,2,19),(71,3,19),(71,4,19),(72,1,21),(72,2,21),(72,3,21),(72,4,21);
/*!40000 ALTER TABLE `asignacion_permisos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bitacora`
--

DROP TABLE IF EXISTS `bitacora`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bitacora` (
  `id_bitacora` int(11) NOT NULL AUTO_INCREMENT,
  `fecha_hora` datetime NOT NULL,
  `accion` varchar(20) NOT NULL,
  `usuario_id` int(11) NOT NULL,
  `modulo_id` int(11) NOT NULL,
  `valores_anteriores` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '{}' CHECK (json_valid(`valores_anteriores`)),
  `valores_nuevos` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '{}' CHECK (json_valid(`valores_nuevos`)),
  PRIMARY KEY (`id_bitacora`),
  KEY `bitacora_ibfk_1` (`usuario_id`),
  KEY `bitacora_ibfk_2` (`modulo_id`),
  CONSTRAINT `bitacora_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id_usuario`) ON UPDATE CASCADE,
  CONSTRAINT `bitacora_ibfk_2` FOREIGN KEY (`modulo_id`) REFERENCES `modulos` (`id_modulo`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=421 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bitacora`
--

LOCK TABLES `bitacora` WRITE;
/*!40000 ALTER TABLE `bitacora` DISABLE KEYS */;
INSERT INTO `bitacora` VALUES (1,'2026-06-18 12:09:56','CONSULTAR',1,1,'{}','{}'),(2,'2026-06-18 12:10:00','CONSULTAR',1,2,'{}','{}'),(3,'2026-06-18 12:10:03','CONSULTAR',1,4,'{}','{}'),(4,'2026-06-18 12:10:07','CONSULTAR',1,3,'{}','{}'),(5,'2026-06-18 12:10:09','CONSULTAR',1,5,'{}','{}'),(6,'2026-06-18 12:10:17','CONSULTAR',1,7,'{}','{}'),(7,'2026-06-18 12:10:19','CONSULTAR',1,8,'{}','{}'),(8,'2026-06-18 12:10:23','CONSULTAR',1,9,'{}','{}'),(9,'2026-06-18 12:10:30','CONSULTAR',1,14,'{}','{}'),(10,'2026-06-18 12:10:38','CONSULTAR',1,17,'{}','{}'),(11,'2026-06-18 12:10:45','CONSULTAR',1,22,'{}','{}'),(12,'2026-06-18 12:10:47','CONSULTAR',1,22,'{}','{}'),(13,'2026-06-18 12:10:49','CONSULTAR',1,23,'{}','{}'),(14,'2026-06-18 12:11:03','CONSULTAR',1,3,'{}','{}'),(15,'2026-06-19 16:21:12','INICIAR SESION',1,14,'{}','{}'),(16,'2026-06-19 16:22:32','CONSULTAR',1,5,'{}','{}'),(17,'2026-06-19 16:22:38','CONSULTAR',1,3,'{}','{}'),(18,'2026-06-19 16:23:02','REGISTRAR',1,3,'{}','{\"tasa_dolar\":\"607.39\",\"mes\":\"1\",\"anio\":\"2026\",\"porcentaje_interes\":\"10\",\"limite_mensualidad\":\"15\"}'),(19,'2026-06-19 16:32:48','CONSULTAR',1,14,'{}','{}'),(20,'2026-06-19 16:38:11','MODIFICAR',1,14,'{}','{\"contra\":\"\"}'),(21,'2026-06-19 16:57:52','CONSULTAR',1,14,'{}','{}'),(22,'2026-06-19 16:58:19','CONSULTAR',1,14,'{}','{}'),(23,'2026-06-19 17:02:45','CONSULTAR',1,14,'{}','{}'),(24,'2026-06-19 17:03:04','CONSULTAR',1,14,'{}','{}'),(25,'2026-06-19 17:03:47','CONSULTAR',1,14,'{}','{}'),(26,'2026-06-19 17:04:34','CONSULTAR',1,14,'{}','{}'),(27,'2026-06-19 17:05:05','CONSULTAR',1,14,'{}','{}'),(28,'2026-06-19 17:05:49','CONSULTAR',1,14,'{}','{}'),(29,'2026-06-19 17:06:12','MODIFICAR',1,14,'{}','{\"contra\":\"\"}'),(30,'2026-06-19 17:08:56','CONSULTAR',1,1,'{}','{}'),(31,'2026-06-19 17:09:59','CONSULTAR',1,3,'{}','{}'),(32,'2026-06-19 17:12:45','ELIMINAR',1,3,'{\"tasa_dolar\":\"607.39\",\"mes\":\"1\",\"anio\":\"2026\",\"porcentaje_interes\":\"10.00\",\"limite_mensualidad\":15}','{}'),(33,'2026-06-19 17:12:54','REGISTRAR',1,3,'{}','{\"tasa_dolar\":\"607.39\",\"mes\":\"1\",\"anio\":\"2026\",\"porcentaje_interes\":\"10\",\"limite_mensualidad\":\"15\"}'),(34,'2026-06-19 17:13:17','REGISTRAR',1,3,'{}','{\"tasa_dolar\":\"607.39\",\"mes\":\"3\",\"anio\":\"2026\",\"porcentaje_interes\":\"10.00\",\"limite_mensualidad\":\"15\"}'),(35,'2026-06-19 17:13:23','CONSULTAR',1,5,'{}','{}'),(36,'2026-06-19 17:13:25','CONSULTAR',1,3,'{}','{}'),(37,'2026-06-19 17:13:31','CONSULTAR',1,7,'{}','{}'),(38,'2026-06-19 17:13:41','CONSULTAR',1,8,'{}','{}'),(39,'2026-06-19 17:13:47','MODIFICAR',1,8,'{\"cuota_reserva\":\"10.00\"}','{\"cuota_reserva\":\"10\",\"tasa_dolar\":\"1\"}'),(40,'2026-06-19 17:16:13','CONSULTAR',1,8,'{}','{}'),(41,'2026-06-19 17:16:25','CONSULTAR',1,8,'{}','{}'),(42,'2026-06-19 17:16:36','CONSULTAR',1,8,'{}','{}'),(43,'2026-06-19 17:20:59','CONSULTAR',1,8,'{}','{}'),(44,'2026-06-19 17:21:22','CONSULTAR',1,8,'{}','{}'),(45,'2026-06-19 17:29:53','CONSULTAR',1,3,'{}','{}'),(46,'2026-06-19 17:29:59','CONSULTAR',1,3,'{}','{}'),(47,'2026-06-19 17:34:11','CONSULTAR',1,3,'{}','{}'),(48,'2026-06-19 17:34:17','CONSULTAR',1,3,'{}','{}'),(49,'2026-06-19 17:36:06','CONSULTAR',1,3,'{}','{}'),(50,'2026-06-19 17:53:57','CONSULTAR',1,3,'{}','{}'),(51,'2026-06-19 17:55:05','CONSULTAR',1,9,'{}','{}'),(52,'2026-06-19 17:58:56','CONSULTAR',1,9,'{}','{}'),(53,'2026-06-19 17:59:02','CONSULTAR',1,3,'{}','{}'),(54,'2026-06-19 17:59:10','CONSULTAR',1,3,'{}','{}'),(55,'2026-06-19 17:59:49','CONSULTAR',1,3,'{}','{}'),(56,'2026-06-19 18:59:33','CONSULTAR',1,4,'{}','{}'),(57,'2026-06-19 21:57:02','INICIAR SESION',1,14,'{}','{}'),(58,'2026-06-19 21:57:10','CONSULTAR',1,9,'{}','{}'),(59,'2026-06-19 21:57:18','CONSULTAR',1,9,'{}','{}'),(60,'2026-06-19 21:58:52','CONSULTAR',1,9,'{}','{}'),(61,'2026-06-19 22:03:15','CONSULTAR',1,9,'{}','{}'),(62,'2026-06-19 22:03:54','CONSULTAR',1,9,'{}','{}'),(63,'2026-06-19 22:05:11','MODIFICAR',1,9,'{\"estado\":\"ABIERTO\"}','{\"estado\":\"CERRADO\"}'),(64,'2026-06-19 22:05:22','MODIFICAR',1,9,'{\"estado\":\"CERRADO\"}','{\"estado\":\"ABIERTO\"}'),(65,'2026-06-20 11:41:49','INICIAR SESION',1,14,'{}','{}'),(66,'2026-06-20 11:41:58','CONSULTAR',1,9,'{}','{}'),(67,'2026-06-20 11:52:50','MODIFICAR',1,9,'{\"estado\":\"ABIERTO\"}','{\"estado\":\"CERRADO\"}'),(68,'2026-06-20 11:53:08','REGISTRAR',1,9,'{}','{\"fecha_inicio\":\"2026-06-20\",\"fecha_cierre\":\"2027-06-20\",\"estado\":\"ABIERTO\",\"descripcion\":\"año fiscal 2026\"}'),(69,'2026-06-20 11:53:36','CONSULTAR',1,9,'{}','{}'),(70,'2026-06-20 11:56:49','MODIFICAR',1,9,'{\"estado\":\"ABIERTO\"}','{\"estado\":\"CERRADO\"}'),(71,'2026-06-20 11:56:54','MODIFICAR',1,9,'{\"estado\":\"CERRADO\"}','{\"estado\":\"ABIERTO\"}'),(72,'2026-06-20 12:09:47','CONSULTAR',1,9,'{}','{}'),(73,'2026-06-20 12:11:17','CONSULTAR',1,9,'{}','{}'),(74,'2026-06-20 12:14:46','CONSULTAR',1,9,'{}','{}'),(75,'2026-06-20 12:15:30','ELIMINAR',1,9,'{\"estado\":\"CERRADO\",\"fecha_inicio\":\"2026-06-20\",\"fecha_cierre\":\"2027-06-20\",\"descripcion\":\"año fiscal 2026\"}','{}'),(76,'2026-06-20 12:18:49','CONSULTAR',1,9,'{}','{}'),(77,'2026-06-20 12:19:35','CONSULTAR',1,9,'{}','{}'),(78,'2026-06-20 12:20:23','CONSULTAR',1,9,'{}','{}'),(79,'2026-06-20 12:23:49','CONSULTAR',1,9,'{}','{}'),(80,'2026-06-20 12:29:31','CONSULTAR',1,9,'{}','{}'),(81,'2026-06-20 12:32:09','CONSULTAR',1,4,'{}','{}'),(82,'2026-06-20 12:33:46','CONSULTAR',1,4,'{}','{}'),(83,'2026-06-20 12:34:24','CONSULTAR',1,4,'{}','{}'),(84,'2026-06-20 13:31:12','CONSULTAR',1,4,'{}','{}'),(85,'2026-06-20 13:32:08','CONSULTAR',1,4,'{}','{}'),(86,'2026-06-20 13:32:57','REGISTRAR',1,4,'{}','{\"fondo_fijo\":\"5000\",\"descripcion\":\"caja chica inicial\"}'),(87,'2026-06-20 13:35:35','CONSULTAR',1,4,'{}','{}'),(88,'2026-06-20 13:35:58','CONSULTAR',1,4,'{}','{}'),(89,'2026-06-20 13:36:32','CONSULTAR',1,4,'{}','{}'),(90,'2026-06-20 13:37:47','CONSULTAR',1,4,'{}','{}'),(91,'2026-06-20 13:38:03','CONSULTAR',1,4,'{}','{}'),(92,'2026-06-20 13:39:51','CONSULTAR',1,4,'{}','{}'),(93,'2026-06-20 13:41:00','CONSULTAR',1,4,'{}','{}'),(94,'2026-06-20 13:48:29','CONSULTAR',1,4,'{}','{}'),(95,'2026-06-20 13:48:35','CONSULTAR',1,4,'{}','{}'),(96,'2026-06-20 13:54:48','CONSULTAR',1,4,'{}','{}'),(97,'2026-06-20 13:55:05','REGISTRAR',1,4,'{}','{\"fondo_fijo\":\"6073.92\",\"descripcion\":\"caja chica 2026\"}'),(98,'2026-06-20 16:04:05','INICIAR SESION',1,14,'{}','{}'),(99,'2026-06-20 16:05:39','CONSULTAR',1,8,'{}','{}'),(100,'2026-06-20 16:06:14','CONSULTAR',1,8,'{}','{}'),(101,'2026-06-20 16:06:56','CONSULTAR',1,4,'{}','{}'),(102,'2026-06-20 16:07:12','CONSULTAR',1,8,'{}','{}'),(103,'2026-06-20 16:11:48','CONSULTAR',1,8,'{}','{}'),(104,'2026-06-20 16:21:10','CONSULTAR',1,8,'{}','{}'),(105,'2026-06-20 16:22:11','CONSULTAR',1,8,'{}','{}'),(106,'2026-06-20 16:23:04','REGISTRAR',1,8,'{}','{\"fecha\":\"2026-02-01\",\"cuota_reserva\":\"10\",\"observacion\":\"Sin observación\",\"tasa_dolar\":607.3919}'),(107,'2026-06-20 16:25:22','CONSULTAR',1,8,'{}','{}'),(108,'2026-06-20 16:25:38','CONSULTAR',1,8,'{}','{}'),(109,'2026-06-20 16:26:15','CONSULTAR',1,8,'{}','{}'),(110,'2026-06-20 16:26:56','MODIFICAR',1,8,'{\"cuota_reserva\":\"10.00\"}','{\"cuota_reserva\":\"10\",\"tasa_dolar\":607.3919}'),(111,'2026-06-20 16:27:23','MODIFICAR',1,8,'{\"cuota_reserva\":\"10.00\"}','{\"cuota_reserva\":\"10\",\"tasa_dolar\":607.3919}'),(112,'2026-06-20 16:30:02','CONSULTAR',1,8,'{}','{}'),(113,'2026-06-20 16:36:21','CONSULTAR',1,8,'{}','{}'),(114,'2026-06-20 16:41:38','CONSULTAR',1,8,'{}','{}'),(115,'2026-06-20 16:53:19','ELIMINAR',1,8,'{\"fecha\":\"2026-05-01\",\"cuota_reserva\":\"10.00\",\"observacion\":\"presupuesto mayo\"}','{}'),(116,'2026-06-20 16:53:25','CONSULTAR',1,1,'{}','{}'),(117,'2026-06-20 16:53:31','CONSULTAR',1,3,'{}','{}'),(118,'2026-06-20 16:53:37','CONSULTAR',1,8,'{}','{}'),(119,'2026-06-20 16:53:40','ELIMINAR',1,8,'{\"fecha\":\"2026-02-01\",\"cuota_reserva\":\"10.00\",\"observacion\":\"Sin observación\"}','{}'),(120,'2026-06-20 16:53:43','CONSULTAR',1,3,'{}','{}'),(121,'2026-06-20 16:53:47','CONSULTAR',1,3,'{}','{}'),(122,'2026-06-20 17:03:56','CONSULTAR',1,3,'{}','{}'),(123,'2026-06-20 17:04:01','CONSULTAR',1,8,'{}','{}'),(124,'2026-06-20 17:04:04','CONSULTAR',1,3,'{}','{}'),(125,'2026-06-20 17:11:34','ELIMINAR',1,3,'{}','{}'),(126,'2026-06-20 17:11:38','CONSULTAR',1,3,'{}','{}'),(127,'2026-06-20 17:11:42','ELIMINAR',1,3,'{\"tasa_dolar\":\"607.39\",\"mes\":\"3\",\"anio\":\"2026\",\"porcentaje_interes\":\"10.00\",\"limite_mensualidad\":15}','{}'),(128,'2026-06-20 17:11:45','ELIMINAR',1,3,'{}','{}'),(129,'2026-06-20 17:12:48','CONSULTAR',1,8,'{}','{}'),(130,'2026-06-20 17:12:58','ELIMINAR',1,8,'{\"fecha\":\"2026-03-01\",\"cuota_reserva\":\"234.00\",\"observacion\":\"Sin observación\"}','{}'),(131,'2026-06-20 17:13:03','CONSULTAR',1,3,'{}','{}'),(132,'2026-06-20 17:13:07','CONSULTAR',1,8,'{}','{}'),(133,'2026-06-20 17:13:11','ELIMINAR',1,8,'{\"fecha\":\"2026-01-01\",\"cuota_reserva\":\"10.00\",\"observacion\":\"enero 2026\"}','{}'),(134,'2026-06-20 17:13:16','CONSULTAR',1,3,'{}','{}'),(135,'2026-06-20 17:14:32','CONSULTAR',1,3,'{}','{}'),(136,'2026-06-20 17:14:40','CONSULTAR',1,8,'{}','{}'),(137,'2026-06-20 17:21:18','CONSULTAR',1,8,'{}','{}'),(138,'2026-06-20 17:21:28','CONSULTAR',1,8,'{}','{}'),(139,'2026-06-20 17:21:58','CONSULTAR',1,8,'{}','{}'),(140,'2026-06-20 17:22:46','REGISTRAR',1,8,'{}','{\"fecha\":\"2026-05-01\",\"cuota_reserva\":\"10\",\"observacion\":\"Sin observación\",\"tasa_dolar\":607.3919}'),(141,'2026-06-20 17:23:04','CONSULTAR',1,3,'{}','{}'),(142,'2026-06-20 17:23:32','CONSULTAR',1,3,'{}','{}'),(143,'2026-06-20 17:23:49','CONSULTAR',1,3,'{}','{}'),(144,'2026-06-20 17:51:47','CONSULTAR',1,8,'{}','{}'),(145,'2026-06-20 17:52:06','CONSULTAR',1,1,'{}','{}'),(146,'2026-06-20 17:52:52','CONSULTAR',1,8,'{}','{}'),(147,'2026-06-20 17:53:39','CONSULTAR',1,8,'{}','{}'),(148,'2026-06-20 17:53:45','CONSULTAR',1,8,'{}','{}'),(149,'2026-06-20 17:55:08','CONSULTAR',1,8,'{}','{}'),(150,'2026-06-20 17:55:48','CONSULTAR',1,8,'{}','{}'),(151,'2026-06-20 17:56:36','CONSULTAR',1,8,'{}','{}'),(152,'2026-06-20 17:57:13','CONSULTAR',1,8,'{}','{}'),(153,'2026-06-20 17:57:32','CONSULTAR',1,8,'{}','{}'),(154,'2026-06-20 17:59:22','CONSULTAR',1,3,'{}','{}'),(155,'2026-06-20 17:59:30','REGISTRAR',1,3,'{}','{\"tasa_dolar\":607.3919,\"mes\":\"4\",\"anio\":\"2026\",\"porcentaje_interes\":\"10\",\"limite_mensualidad\":\"15\"}'),(156,'2026-06-20 17:59:42','CONSULTAR',1,1,'{}','{}'),(157,'2026-06-20 18:02:27','REGISTRAR',1,1,'{}','{\"estado\":\"PROCESADO\",\"observacion\":\"pago\",\"tasa_dolar\":607.3919}'),(158,'2026-06-20 18:04:58','CONSULTAR',1,3,'{}','{}'),(159,'2026-06-20 18:05:01','ELIMINAR',1,3,'{\"tasa_dolar\":\"607.39\",\"mes\":\"4\",\"anio\":\"2026\",\"porcentaje_interes\":\"10.00\",\"limite_mensualidad\":15}','{}'),(160,'2026-06-20 18:05:07','CONSULTAR',1,1,'{}','{}'),(161,'2026-06-20 18:05:31','CONSULTAR',1,8,'{}','{}'),(162,'2026-06-20 18:11:16','CONSULTAR',1,1,'{}','{}'),(163,'2026-06-20 18:11:48','CONSULTAR',1,8,'{}','{}'),(164,'2026-06-20 18:12:00','ELIMINAR',1,8,'{\"fecha\":\"2026-04-01\",\"cuota_reserva\":\"10.00\",\"observacion\":\"presupuesto abril\"}','{}'),(165,'2026-06-20 18:16:57','CONSULTAR',1,3,'{}','{}'),(166,'2026-06-20 18:17:03','REGISTRAR',1,3,'{}','{\"tasa_dolar\":607.3919,\"mes\":\"5\",\"anio\":\"2026\",\"porcentaje_interes\":\"10\",\"limite_mensualidad\":\"15\"}'),(167,'2026-06-20 18:17:39','CONSULTAR',1,1,'{}','{}'),(168,'2026-06-20 18:17:41','ELIMINAR',1,1,'{\"estado\":\"RECHAZADO\",\"observacion\":\"pago\"}','{}'),(169,'2026-06-20 18:18:00','REGISTRAR',1,1,'{}','{\"estado\":\"PENDIENTE\",\"observacion\":\"pago pendiente\",\"tasa_dolar\":607.3919}'),(170,'2026-06-20 18:18:08','CONSULTAR',1,3,'{}','{}'),(171,'2026-06-20 18:18:10','ELIMINAR',1,3,'{\"tasa_dolar\":\"607.39\",\"mes\":\"5\",\"anio\":\"2026\",\"porcentaje_interes\":\"10.00\",\"limite_mensualidad\":15}','{}'),(172,'2026-06-20 18:19:10','CONSULTAR',1,1,'{}','{}'),(173,'2026-06-20 18:19:20','CONSULTAR',1,3,'{}','{}'),(174,'2026-06-20 18:19:25','REGISTRAR',1,3,'{}','{\"tasa_dolar\":607.3919,\"mes\":\"5\",\"anio\":\"2026\",\"porcentaje_interes\":\"10\",\"limite_mensualidad\":\"15\"}'),(175,'2026-06-20 18:19:32','CONSULTAR',1,1,'{}','{}'),(176,'2026-06-20 18:20:40','ELIMINAR',1,1,'{\"estado\":\"PENDIENTE\",\"observacion\":\"pago pendiente\"}','{}'),(177,'2026-06-20 18:21:04','REGISTRAR',1,1,'{}','{\"estado\":\"PROCESADO\",\"observacion\":\"pagg\",\"tasa_dolar\":607.3919}'),(178,'2026-06-20 18:21:13','CONSULTAR',1,3,'{}','{}'),(179,'2026-06-20 18:21:30','CONSULTAR',1,1,'{}','{}'),(180,'2026-06-20 18:21:32','CONSULTAR',1,3,'{}','{}'),(181,'2026-06-20 18:21:44','ELIMINAR',1,3,'{\"tasa_dolar\":\"607.39\",\"mes\":\"5\",\"anio\":\"2026\",\"porcentaje_interes\":\"10.00\",\"limite_mensualidad\":15}','{}'),(182,'2026-06-20 18:24:45','REGISTRAR',1,3,'{}','{\"tasa_dolar\":607.3919,\"mes\":\"5\",\"anio\":\"2026\",\"porcentaje_interes\":\"10\",\"limite_mensualidad\":\"15\"}'),(183,'2026-06-20 18:24:53','CONSULTAR',1,1,'{}','{}'),(184,'2026-06-20 18:25:10','REGISTRAR',1,1,'{}','{\"estado\":\"PENDIENTE\",\"observacion\":\"pago\",\"tasa_dolar\":607.3919}'),(185,'2026-06-20 18:25:17','CONSULTAR',1,3,'{}','{}'),(186,'2026-06-20 18:27:06','CONSULTAR',1,8,'{}','{}'),(187,'2026-06-20 18:35:08','CONSULTAR',1,3,'{}','{}'),(188,'2026-06-20 18:35:24','CONSULTAR',1,1,'{}','{}'),(189,'2026-06-20 18:35:42','MODIFICAR',1,1,'{\"estado\":\"PENDIENTE\"}','{\"estado\":\"PROCESADO\",\"tasa_dolar\":607.3919}'),(190,'2026-06-20 18:35:48','CONSULTAR',1,3,'{}','{}'),(191,'2026-06-20 18:35:53','CONSULTAR',1,1,'{}','{}'),(192,'2026-06-20 18:36:07','MODIFICAR',1,1,'{\"estado\":\"PROCESADO\"}','{\"estado\":\"RECHAZADO\",\"tasa_dolar\":607.3919}'),(193,'2026-06-20 18:36:12','CONSULTAR',1,3,'{}','{}'),(194,'2026-06-20 18:36:14','ELIMINAR',1,3,'{\"tasa_dolar\":\"607.39\",\"mes\":\"5\",\"anio\":\"2026\",\"porcentaje_interes\":\"10.00\",\"limite_mensualidad\":15}','{}'),(195,'2026-06-21 15:56:22','INICIAR SESION',1,14,'{}','{}'),(196,'2026-06-21 15:56:29','CONSULTAR',1,1,'{}','{}'),(197,'2026-06-21 15:56:32','CONSULTAR',1,1,'{}','{}'),(198,'2026-06-21 15:58:15','CONSULTAR',1,1,'{}','{}'),(199,'2026-06-21 15:58:56','CONSULTAR',1,1,'{}','{}'),(200,'2026-06-21 16:00:19','CONSULTAR',1,1,'{}','{}'),(201,'2026-06-21 16:00:38','CONSULTAR',1,3,'{}','{}'),(202,'2026-06-21 16:00:45','CONSULTAR',1,1,'{}','{}'),(203,'2026-06-21 16:00:48','CONSULTAR',1,3,'{}','{}'),(204,'2026-06-21 16:01:20','CONSULTAR',1,15,'{}','{}'),(205,'2026-06-21 16:01:26','CONSULTAR',1,3,'{}','{}'),(206,'2026-06-21 16:01:36','CONSULTAR',1,1,'{}','{}'),(207,'2026-06-21 16:04:30','CONSULTAR',1,1,'{}','{}'),(208,'2026-06-21 16:04:59','CONSULTAR',1,1,'{}','{}'),(209,'2026-06-21 16:06:45','CONSULTAR',1,1,'{}','{}'),(210,'2026-06-21 16:07:33','CONSULTAR',1,1,'{}','{}'),(211,'2026-06-21 16:07:37','CONSULTAR',1,1,'{}','{}'),(212,'2026-06-21 16:57:13','CONSULTAR',1,1,'{}','{}'),(213,'2026-06-21 17:26:34','CONSULTAR',1,15,'{}','{}'),(214,'2026-06-21 17:26:48','CONSULTAR',1,15,'{}','{}'),(215,'2026-06-21 17:26:50','CONSULTAR',1,15,'{}','{}'),(216,'2026-06-21 17:30:16','CONSULTAR',1,1,'{}','{}'),(217,'2026-06-21 17:38:53','CONSULTAR',1,3,'{}','{}'),(218,'2026-06-21 17:38:56','CONSULTAR',1,3,'{}','{}'),(219,'2026-06-21 17:39:06','REGISTRAR',1,3,'{}','{\"tasa_dolar\":607.3919,\"mes\":\"5\",\"anio\":\"2026\",\"porcentaje_interes\":\"10\",\"limite_mensualidad\":\"15\"}'),(220,'2026-06-21 17:48:42','CONSULTAR',1,3,'{}','{}'),(221,'2026-06-21 17:49:12','MODIFICAR',1,3,'{\"tasa_dolar\":\"607.39\"}','{\"tasa_dolar\":607.3919}'),(222,'2026-06-21 17:49:22','CONSULTAR',1,8,'{}','{}'),(223,'2026-06-21 17:49:36','CONSULTAR',1,3,'{}','{}'),(224,'2026-06-21 17:49:40','ELIMINAR',1,3,'{\"tasa_dolar\":\"607.39\",\"mes\":\"5\",\"anio\":\"2026\",\"porcentaje_interes\":\"10.00\",\"limite_mensualidad\":15}','{}'),(225,'2026-06-21 17:49:47','REGISTRAR',1,3,'{}','{\"tasa_dolar\":607.3919,\"mes\":\"5\",\"anio\":\"2026\",\"porcentaje_interes\":\"10\",\"limite_mensualidad\":\"15\"}'),(226,'2026-06-21 17:50:00','CONSULTAR',1,1,'{}','{}'),(227,'2026-06-21 17:51:02','CONSULTAR',1,1,'{}','{}'),(228,'2026-06-21 17:51:50','CONSULTAR',1,1,'{}','{}'),(229,'2026-06-21 17:52:02','CONSULTAR',1,1,'{}','{}'),(230,'2026-06-21 17:52:29','REGISTRAR',1,1,'{}','{\"estado\":\"PROCESADO\",\"observacion\":\"pago\",\"tasa_dolar\":607.3919}'),(231,'2026-06-21 17:52:50','CONSULTAR',1,3,'{}','{}'),(232,'2026-06-21 17:52:58','CONSULTAR',1,15,'{}','{}'),(233,'2026-06-21 17:53:33','CONSULTAR',1,3,'{}','{}'),(234,'2026-06-21 18:25:20','CONSULTAR',1,1,'{}','{}'),(235,'2026-06-21 18:25:25','CONSULTAR',1,3,'{}','{}'),(236,'2026-06-21 18:35:39','CONSULTAR',1,3,'{}','{}'),(237,'2026-06-21 18:35:45','CONSULTAR',1,1,'{}','{}'),(238,'2026-06-21 18:35:47','ELIMINAR',1,1,'{\"estado\":\"PROCESADO\",\"observacion\":\"pago\"}','{}'),(239,'2026-06-21 18:35:50','ELIMINAR',1,1,'{\"estado\":\"RECHAZADO\",\"observacion\":\"pago\"}','{}'),(240,'2026-06-21 18:35:53','CONSULTAR',1,3,'{}','{}'),(241,'2026-06-21 18:35:59','CONSULTAR',1,8,'{}','{}'),(242,'2026-06-21 18:36:01','ELIMINAR',1,8,'{\"fecha\":\"2026-05-01\",\"cuota_reserva\":\"10.00\",\"observacion\":\"Sin observación\"}','{}'),(243,'2026-06-21 18:36:04','CONSULTAR',1,3,'{}','{}'),(244,'2026-06-21 18:36:13','CONSULTAR',1,9,'{}','{}'),(245,'2026-06-21 18:37:41','CONSULTAR',1,19,'{}','{}'),(246,'2026-06-21 18:38:11','CONSULTAR',1,19,'{}','{}'),(247,'2026-06-21 18:38:25','RESPALDAR',1,19,'{}','{\"accion\":\"Generó copia de seguridad\",\"base_datos\":\"NEGOCIO\"}'),(248,'2026-06-21 18:38:31','RESPALDAR',1,19,'{}','{\"accion\":\"Generó copia de seguridad\",\"base_datos\":\"SEGURIDAD\"}'),(249,'2026-06-21 18:54:12','CONSULTAR',1,3,'{}','{}'),(250,'2026-06-21 18:54:16','CONSULTAR',1,3,'{}','{}'),(251,'2026-06-21 18:54:23','CONSULTAR',1,8,'{}','{}'),(252,'2026-06-21 18:54:53','REGISTRAR',1,8,'{}','{\"fecha\":\"2026-01-01\",\"cuota_reserva\":\"10\",\"observacion\":\"presupuesto mes de enero\",\"tasa_dolar\":607.3919}'),(253,'2026-06-21 18:54:57','CONSULTAR',1,3,'{}','{}'),(254,'2026-06-21 18:56:02','MODIFICAR',1,3,'{\"tasa_dolar\":\"607.39\"}','{\"tasa_dolar\":607.3919}'),(255,'2026-06-21 18:57:11','MODIFICAR',1,3,'{\"tasa_dolar\":\"607.39\"}','{\"tasa_dolar\":607.3919}'),(256,'2026-06-21 19:03:39','CONSULTAR',1,1,'{}','{}'),(257,'2026-06-21 19:03:53','REGISTRAR',1,1,'{}','{\"estado\":\"PROCESADO\",\"observacion\":\"pago\",\"tasa_dolar\":607.3919}'),(258,'2026-06-21 19:05:02','CONSULTAR',1,1,'{}','{}'),(259,'2026-06-21 19:18:06','REGISTRAR',1,1,'{}','{\"estado\":\"PROCESADO\",\"observacion\":\"\",\"tasa_dolar\":607.3919}'),(260,'2026-06-21 19:26:39','CONSULTAR',1,3,'{}','{}'),(261,'2026-06-21 19:26:43','CONSULTAR',1,1,'{}','{}'),(262,'2026-06-21 19:26:44','ELIMINAR',1,1,'{\"estado\":\"PROCESADO\",\"observacion\":\"pago\"}','{}'),(263,'2026-06-21 19:26:48','ELIMINAR',1,1,'{\"estado\":\"PROCESADO\",\"observacion\":\"\"}','{}'),(264,'2026-06-21 19:26:51','CONSULTAR',1,3,'{}','{}'),(265,'2026-06-21 19:26:57','REGISTRAR',1,3,'{}','{\"tasa_dolar\":607.3919,\"mes\":\"1\",\"anio\":\"2026\",\"porcentaje_interes\":\"10\",\"limite_mensualidad\":\"15\"}'),(266,'2026-06-21 19:27:06','CONSULTAR',1,1,'{}','{}'),(267,'2026-06-21 19:27:21','REGISTRAR',1,1,'{}','{\"estado\":\"PROCESADO\",\"observacion\":\"\",\"tasa_dolar\":607.3919}'),(268,'2026-06-21 19:27:30','CONSULTAR',1,3,'{}','{}'),(269,'2026-06-21 23:27:47','INICIAR SESION',1,14,'{}','{}'),(270,'2026-06-21 23:28:09','CONSULTAR',1,1,'{}','{}'),(271,'2026-06-21 23:28:13','CONSULTAR',1,3,'{}','{}'),(272,'2026-06-22 09:59:44','INICIAR SESION',1,14,'{}','{}'),(273,'2026-06-22 09:59:52','CONSULTAR',1,3,'{}','{}'),(274,'2026-06-22 10:08:51','CONSULTAR',1,3,'{}','{}'),(275,'2026-06-22 10:15:04','CONSULTAR',1,3,'{}','{}'),(276,'2026-06-22 10:20:29','CONSULTAR',1,3,'{}','{}'),(277,'2026-06-22 10:21:19','CONSULTAR',1,3,'{}','{}'),(278,'2026-06-22 10:21:41','CONSULTAR',1,3,'{}','{}'),(279,'2026-06-22 10:23:15','CONSULTAR',1,3,'{}','{}'),(280,'2026-06-22 10:23:33','CONSULTAR',1,3,'{}','{}'),(281,'2026-06-22 10:24:16','CONSULTAR',1,3,'{}','{}'),(282,'2026-06-22 10:25:16','CONSULTAR',1,3,'{}','{}'),(283,'2026-06-22 10:25:46','CONSULTAR',1,3,'{}','{}'),(284,'2026-06-22 10:25:58','CONSULTAR',1,3,'{}','{}'),(285,'2026-06-22 10:27:14','CONSULTAR',1,3,'{}','{}'),(286,'2026-06-22 10:29:00','CONSULTAR',1,3,'{}','{}'),(287,'2026-06-22 10:29:45','CONSULTAR',1,3,'{}','{}'),(288,'2026-06-22 10:30:05','CONSULTAR',1,3,'{}','{}'),(289,'2026-06-22 10:30:24','CONSULTAR',1,3,'{}','{}'),(290,'2026-06-22 10:30:36','CONSULTAR',1,3,'{}','{}'),(291,'2026-06-22 10:31:59','CONSULTAR',1,3,'{}','{}'),(292,'2026-06-22 10:32:29','CONSULTAR',1,3,'{}','{}'),(293,'2026-06-22 10:33:06','CONSULTAR',1,3,'{}','{}'),(294,'2026-06-22 10:34:43','CONSULTAR',1,3,'{}','{}'),(295,'2026-06-22 10:35:10','CONSULTAR',1,3,'{}','{}'),(296,'2026-06-22 10:35:33','CONSULTAR',1,3,'{}','{}'),(297,'2026-06-22 10:39:03','CONSULTAR',1,3,'{}','{}'),(298,'2026-06-22 10:39:34','CONSULTAR',1,3,'{}','{}'),(299,'2026-06-22 10:40:29','CONSULTAR',1,3,'{}','{}'),(300,'2026-06-22 10:43:19','CONSULTAR',1,3,'{}','{}'),(301,'2026-06-22 10:44:13','CONSULTAR',1,3,'{}','{}'),(302,'2026-06-22 10:45:21','CONSULTAR',1,3,'{}','{}'),(303,'2026-06-22 10:45:44','CONSULTAR',1,3,'{}','{}'),(304,'2026-06-22 10:53:35','CONSULTAR',1,3,'{}','{}'),(305,'2026-06-22 10:54:09','CONSULTAR',1,3,'{}','{}'),(306,'2026-06-22 10:55:35','CONSULTAR',1,3,'{}','{}'),(307,'2026-06-22 10:57:17','CONSULTAR',1,3,'{}','{}'),(308,'2026-06-22 10:57:45','CONSULTAR',1,3,'{}','{}'),(309,'2026-06-22 11:00:12','CONSULTAR',1,3,'{}','{}'),(310,'2026-06-22 11:00:35','CONSULTAR',1,3,'{}','{}'),(311,'2026-06-22 11:01:13','CONSULTAR',1,3,'{}','{}'),(312,'2026-06-22 11:01:41','CONSULTAR',1,3,'{}','{}'),(313,'2026-06-22 11:02:55','CONSULTAR',1,3,'{}','{}'),(314,'2026-06-22 11:03:08','CONSULTAR',1,3,'{}','{}'),(315,'2026-06-22 11:03:28','CONSULTAR',1,3,'{}','{}'),(316,'2026-06-22 11:03:45','CONSULTAR',1,3,'{}','{}'),(317,'2026-06-22 11:06:45','CONSULTAR',1,3,'{}','{}'),(318,'2026-06-22 11:07:21','CONSULTAR',1,3,'{}','{}'),(319,'2026-06-22 11:09:50','CONSULTAR',1,3,'{}','{}'),(320,'2026-06-22 11:17:24','CONSULTAR',1,3,'{}','{}'),(321,'2026-06-22 11:19:18','CONSULTAR',1,3,'{}','{}'),(322,'2026-06-22 11:20:40','CONSULTAR',1,3,'{}','{}'),(323,'2026-06-22 11:28:25','CONSULTAR',1,3,'{}','{}'),(324,'2026-06-22 11:32:23','CONSULTAR',1,3,'{}','{}'),(325,'2026-06-22 11:37:04','CONSULTAR',1,3,'{}','{}'),(326,'2026-06-22 11:48:44','CONSULTAR',1,3,'{}','{}'),(327,'2026-06-22 11:58:55','CONSULTAR',1,3,'{}','{}'),(328,'2026-06-22 11:59:30','CONSULTAR',1,3,'{}','{}'),(329,'2026-06-22 12:08:54','CONSULTAR',1,3,'{}','{}'),(330,'2026-06-22 12:10:34','CONSULTAR',1,3,'{}','{}'),(331,'2026-06-22 12:10:59','CONSULTAR',1,3,'{}','{}'),(332,'2026-06-22 12:13:54','CONSULTAR',1,3,'{}','{}'),(333,'2026-06-22 12:14:19','CONSULTAR',1,8,'{}','{}'),(334,'2026-06-22 12:14:51','REGISTRAR',1,8,'{}','{\"fecha\":\"2026-02-01\",\"cuota_reserva\":\"10\",\"observacion\":\"Presupuesto mes de febrero\",\"tasa_dolar\":612.4332}'),(335,'2026-06-22 12:14:57','CONSULTAR',1,3,'{}','{}'),(336,'2026-06-22 12:15:06','MODIFICAR',1,3,'{\"tasa_dolar\":\"612.43\"}','{\"tasa_dolar\":612.4332}'),(337,'2026-06-22 12:35:44','CONSULTAR',1,3,'{}','{}'),(338,'2026-06-22 16:41:03','INICIAR SESION',1,14,'{}','{}'),(339,'2026-06-22 16:41:16','CONSULTAR',1,3,'{}','{}'),(340,'2026-06-22 16:51:10','CONSULTAR',1,3,'{}','{}'),(341,'2026-06-22 16:51:40','CONSULTAR',1,3,'{}','{}'),(342,'2026-06-22 16:54:25','CONSULTAR',1,3,'{}','{}'),(343,'2026-06-22 16:56:22','CONSULTAR',1,3,'{}','{}'),(344,'2026-06-22 16:57:16','CONSULTAR',1,3,'{}','{}'),(345,'2026-06-22 16:57:55','CONSULTAR',1,3,'{}','{}'),(346,'2026-06-22 16:59:07','CONSULTAR',1,3,'{}','{}'),(347,'2026-06-22 17:00:17','CONSULTAR',1,3,'{}','{}'),(348,'2026-06-22 17:01:03','CONSULTAR',1,3,'{}','{}'),(349,'2026-06-22 17:02:27','CONSULTAR',1,3,'{}','{}'),(350,'2026-06-22 17:03:12','CONSULTAR',1,3,'{}','{}'),(351,'2026-06-22 17:08:32','CONSULTAR',1,3,'{}','{}'),(352,'2026-06-22 17:09:26','CONSULTAR',1,3,'{}','{}'),(353,'2026-06-22 17:13:28','CONSULTAR',1,3,'{}','{}'),(354,'2026-06-22 17:13:48','CONSULTAR',1,3,'{}','{}'),(355,'2026-06-22 17:14:40','CONSULTAR',1,3,'{}','{}'),(356,'2026-06-22 17:15:39','CONSULTAR',1,3,'{}','{}'),(357,'2026-06-22 17:16:15','CONSULTAR',1,3,'{}','{}'),(358,'2026-06-22 17:16:48','CONSULTAR',1,3,'{}','{}'),(359,'2026-06-22 17:18:58','CONSULTAR',1,3,'{}','{}'),(360,'2026-06-22 17:19:38','CONSULTAR',1,3,'{}','{}'),(361,'2026-06-22 17:21:37','CONSULTAR',1,3,'{}','{}'),(362,'2026-06-22 17:22:27','CONSULTAR',1,3,'{}','{}'),(363,'2026-06-22 17:23:02','CONSULTAR',1,3,'{}','{}'),(364,'2026-06-22 17:25:30','CONSULTAR',1,3,'{}','{}'),(365,'2026-06-22 17:25:52','CONSULTAR',1,3,'{}','{}'),(366,'2026-06-22 17:26:09','CONSULTAR',1,3,'{}','{}'),(367,'2026-06-22 17:27:39','CONSULTAR',1,3,'{}','{}'),(368,'2026-06-22 17:29:53','CONSULTAR',1,3,'{}','{}'),(369,'2026-06-22 17:31:05','CONSULTAR',1,3,'{}','{}'),(370,'2026-06-22 17:48:41','CONSULTAR',1,3,'{}','{}'),(371,'2026-06-22 17:48:48','CONSULTAR',1,3,'{}','{}'),(372,'2026-06-22 17:48:58','CONSULTAR',1,3,'{}','{}'),(373,'2026-06-22 17:49:49','CONSULTAR',1,3,'{}','{}'),(374,'2026-06-22 17:50:22','CONSULTAR',1,3,'{}','{}'),(375,'2026-06-22 17:50:58','CONSULTAR',1,3,'{}','{}'),(376,'2026-06-22 17:55:37','CONSULTAR',1,3,'{}','{}'),(377,'2026-06-22 17:56:25','CONSULTAR',1,3,'{}','{}'),(378,'2026-06-22 17:59:09','CONSULTAR',1,3,'{}','{}'),(379,'2026-06-22 18:00:52','CONSULTAR',1,3,'{}','{}'),(380,'2026-06-22 18:01:01','CONSULTAR',1,3,'{}','{}'),(381,'2026-06-22 18:01:54','CONSULTAR',1,3,'{}','{}'),(382,'2026-06-22 18:02:19','CONSULTAR',1,3,'{}','{}'),(383,'2026-06-22 18:02:42','CONSULTAR',1,3,'{}','{}'),(384,'2026-06-22 18:03:07','CONSULTAR',1,3,'{}','{}'),(385,'2026-06-22 18:03:32','CONSULTAR',1,3,'{}','{}'),(386,'2026-06-22 18:04:09','CONSULTAR',1,3,'{}','{}'),(387,'2026-06-22 18:04:32','CONSULTAR',1,3,'{}','{}'),(388,'2026-06-22 18:04:37','CONSULTAR',1,3,'{}','{}'),(389,'2026-06-22 18:05:14','CONSULTAR',1,3,'{}','{}'),(390,'2026-06-22 18:07:16','CONSULTAR',1,3,'{}','{}'),(391,'2026-06-22 18:07:26','CONSULTAR',1,3,'{}','{}'),(392,'2026-06-22 18:07:39','CONSULTAR',1,3,'{}','{}'),(393,'2026-06-22 18:07:52','CONSULTAR',1,3,'{}','{}'),(394,'2026-06-22 18:08:30','CONSULTAR',1,3,'{}','{}'),(395,'2026-06-22 18:08:34','CONSULTAR',1,3,'{}','{}'),(396,'2026-06-22 18:09:06','CONSULTAR',1,3,'{}','{}'),(397,'2026-06-22 18:10:36','CONSULTAR',1,3,'{}','{}'),(398,'2026-06-22 18:10:48','CONSULTAR',1,3,'{}','{}'),(399,'2026-06-22 18:11:37','CONSULTAR',1,3,'{}','{}'),(400,'2026-06-22 18:18:14','CONSULTAR',1,3,'{}','{}'),(401,'2026-06-22 18:20:18','CONSULTAR',1,3,'{}','{}'),(402,'2026-06-22 18:20:51','CONSULTAR',1,3,'{}','{}'),(403,'2026-06-22 18:52:16','CONSULTAR',1,1,'{}','{}'),(404,'2026-06-22 18:54:06','CONSULTAR',1,1,'{}','{}'),(405,'2026-06-22 18:59:28','CONSULTAR',1,1,'{}','{}'),(406,'2026-06-22 19:04:50','CONSULTAR',1,1,'{}','{}'),(407,'2026-06-22 19:05:13','CONSULTAR',1,19,'{}','{}'),(408,'2026-06-22 19:05:20','RESPALDAR',1,19,'{}','{\"accion\":\"Generó copia de seguridad\",\"base_datos\":\"NEGOCIO\"}'),(409,'2026-06-22 19:05:25','RESPALDAR',1,19,'{}','{\"accion\":\"Generó copia de seguridad\",\"base_datos\":\"SEGURIDAD\"}'),(410,'2026-06-22 19:05:31','CONSULTAR',1,1,'{}','{}'),(411,'2026-06-22 19:06:27','ELIMINAR',1,1,'{\"estado\":\"PROCESADO\",\"observacion\":\"\"}','{}'),(412,'2026-06-22 19:06:31','CONSULTAR',1,3,'{}','{}'),(413,'2026-06-22 19:06:33','ELIMINAR',1,3,'{\"tasa_dolar\":\"612.43\",\"mes\":\"02\",\"anio\":\"2026\",\"porcentaje_interes\":\"10.00\",\"limite_mensualidad\":15}','{}'),(414,'2026-06-22 19:06:36','CONSULTAR',1,8,'{}','{}'),(415,'2026-06-22 19:06:38','ELIMINAR',1,8,'{\"fecha\":\"2026-02-01\",\"cuota_reserva\":\"10.00\",\"observacion\":\"Presupuesto mes de febrero\"}','{}'),(416,'2026-06-22 19:06:40','ELIMINAR',1,8,'{\"fecha\":\"2026-01-01\",\"cuota_reserva\":\"10.00\",\"observacion\":\"presupuesto mes de enero\"}','{}'),(417,'2026-06-22 19:06:44','CONSULTAR',1,9,'{}','{}'),(418,'2026-06-22 19:06:48','CONSULTAR',1,4,'{}','{}'),(419,'2026-06-22 19:07:01','CONSULTAR',1,19,'{}','{}'),(420,'2026-06-22 19:07:06','RESPALDAR',1,19,'{}','{\"accion\":\"Generó copia de seguridad\",\"base_datos\":\"NEGOCIO\"}');
/*!40000 ALTER TABLE `bitacora` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cartelera_virtual`
--

DROP TABLE IF EXISTS `cartelera_virtual`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cartelera_virtual` (
  `id_cartelera` int(11) NOT NULL AUTO_INCREMENT,
  `titulo` varchar(100) NOT NULL,
  `descripcion` text NOT NULL,
  `fecha` datetime NOT NULL DEFAULT current_timestamp(),
  `imagen` varchar(100) DEFAULT NULL,
  `prioridad` varchar(10) NOT NULL,
  `usuario_id` int(11) NOT NULL,
  PRIMARY KEY (`id_cartelera`),
  KEY `cartelera_virtual_ibfk_1` (`usuario_id`),
  CONSTRAINT `cartelera_virtual_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id_usuario`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=66 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cartelera_virtual`
--

LOCK TABLES `cartelera_virtual` WRITE;
/*!40000 ALTER TABLE `cartelera_virtual` DISABLE KEYS */;
/*!40000 ALTER TABLE `cartelera_virtual` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `claves_sesion`
--

DROP TABLE IF EXISTS `claves_sesion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `claves_sesion` (
  `dispositivo_id` varchar(255) NOT NULL,
  `usuario_id` int(11) NOT NULL,
  `clave_aes` text NOT NULL,
  `fecha_creacion` datetime NOT NULL DEFAULT current_timestamp(),
  `ultima_actividad` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`dispositivo_id`),
  KEY `idx_usuario_sesion` (`usuario_id`),
  CONSTRAINT `fk_claves_usuario` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id_usuario`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `claves_sesion`
--

LOCK TABLES `claves_sesion` WRITE;
/*!40000 ALTER TABLE `claves_sesion` DISABLE KEYS */;
INSERT INTO `claves_sesion` VALUES ('3bb214f0-fa54-4ddb-8fdb-556b5ebfb7c1',27,'MppkRgG/dA3zE95NiauhwLhkOM3364f8/u2Oq30yg7g=','2026-06-03 20:42:47','2026-06-03 20:59:38'),('695a0696-feea-4ae0-b902-76ea585c2dff',1,'pIGaBV2l57ep+5sg4NtJE6JzslYU1L06bpKLhNDzhws=','2026-06-14 15:36:20','2026-06-14 15:45:25'),('c6b2c137-59e7-4bd5-b390-48e26acb46c5',1,'ruHyIJ7gmRZeMBNS3V/lHH06XWUQPOtqFz6VnRVt39I=','2026-06-09 23:38:54','2026-06-09 23:49:51');
/*!40000 ALTER TABLE `claves_sesion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eventos_sistema`
--

DROP TABLE IF EXISTS `eventos_sistema`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `eventos_sistema` (
  `id_evento` int(11) NOT NULL AUTO_INCREMENT,
  `tipo_evento` varchar(50) NOT NULL,
  `tabla_origen` varchar(50) NOT NULL,
  `id_registro_origen` int(11) NOT NULL,
  `fecha_evento` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id_evento`)
) ENGINE=InnoDB AUTO_INCREMENT=76 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eventos_sistema`
--

LOCK TABLES `eventos_sistema` WRITE;
/*!40000 ALTER TABLE `eventos_sistema` DISABLE KEYS */;
INSERT INTO `eventos_sistema` VALUES (32,'NUEVA_MENSUALIDAD','mensualidad',669,'2026-05-18 22:20:20'),(33,'NUEVA_MENSUALIDAD','mensualidad',669,'2026-05-18 22:21:23'),(34,'CREACION_AVISO','cartelera_virtual',52,'2026-06-06 17:40:18'),(35,'CREACION_AVISO','cartelera_virtual',53,'2026-06-06 17:42:37'),(36,'CREACION_AVISO','cartelera_virtual',54,'2026-06-06 17:43:52'),(37,'CREACION_AVISO','cartelera_virtual',55,'2026-06-06 18:01:13'),(38,'CREACION_AVISO','cartelera_virtual',56,'2026-06-06 18:08:23'),(39,'CREACION_AVISO','cartelera_virtual',57,'2026-06-06 18:33:31'),(40,'CREACION_AVISO','cartelera_virtual',58,'2026-06-06 18:37:37'),(41,'CREACION_AVISO','cartelera_virtual',59,'2026-06-06 18:50:42'),(42,'CREACION_AVISO','cartelera_virtual',60,'2026-06-07 17:13:02'),(43,'nueva_publicacion','cartelera_virtual',61,'2026-06-07 17:18:43'),(44,'pago_recibido','pagos',160,'2026-06-07 17:40:27'),(45,'nueva_publicacion','cartelera_virtual',62,'2026-06-07 18:30:19'),(46,'nueva_publicacion','cartelera_virtual',63,'2026-06-07 18:30:54'),(47,'nueva_publicacion','cartelera_virtual',64,'2026-06-07 18:32:06'),(48,'pago_recibido','pagos',161,'2026-06-08 11:48:18'),(49,'nueva_publicacion','cartelera_virtual',65,'2026-06-08 12:27:52'),(50,'pago_recibido','pagos',159,'2026-06-08 18:35:23'),(51,'pago_recibido','pagos',160,'2026-06-08 18:40:15'),(52,'pago_recibido','pagos',161,'2026-06-08 18:41:36'),(53,'pago_recibido','pagos',162,'2026-06-08 18:50:43'),(54,'pago_recibido','pagos',163,'2026-06-08 18:51:33'),(55,'pago_recibido','pagos',164,'2026-06-08 18:56:35'),(56,'pago_recibido','pagos',165,'2026-06-08 19:00:06'),(57,'pago_recibido','pagos',166,'2026-06-08 19:00:33'),(58,'nueva_mensualidad','mensualidad',717,'2026-06-19 16:23:02'),(59,'nueva_mensualidad','mensualidad',717,'2026-06-19 17:12:54'),(60,'nueva_mensualidad','mensualidad',741,'2026-06-19 17:13:17'),(61,'nueva_mensualidad','mensualidad',789,'2026-06-20 17:59:31'),(62,'pago_recibido','pagos',167,'2026-06-20 18:02:28'),(63,'nueva_mensualidad','mensualidad',797,'2026-06-20 18:17:04'),(64,'pago_recibido','pagos',168,'2026-06-20 18:18:00'),(65,'nueva_mensualidad','mensualidad',797,'2026-06-20 18:19:25'),(66,'pago_recibido','pagos',169,'2026-06-20 18:21:04'),(67,'nueva_mensualidad','mensualidad',813,'2026-06-20 18:24:45'),(68,'pago_recibido','pagos',170,'2026-06-20 18:25:10'),(69,'nueva_mensualidad','mensualidad',813,'2026-06-21 17:39:07'),(70,'nueva_mensualidad','mensualidad',813,'2026-06-21 17:49:47'),(71,'pago_recibido','pagos',171,'2026-06-21 17:52:30'),(72,'pago_recibido','pagos',172,'2026-06-21 19:03:53'),(73,'pago_recibido','pagos',173,'2026-06-21 19:18:06'),(74,'nueva_mensualidad','mensualidad',869,'2026-06-21 19:26:57'),(75,'pago_recibido','pagos',174,'2026-06-21 19:27:21');
/*!40000 ALTER TABLE `eventos_sistema` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `intentos_login`
--

DROP TABLE IF EXISTS `intentos_login`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `intentos_login` (
  `usuario_id` int(11) NOT NULL,
  `intentos` int(11) NOT NULL DEFAULT 1,
  `ultimo_intento` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`usuario_id`),
  CONSTRAINT `intentos_login_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id_usuario`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `intentos_login`
--

LOCK TABLES `intentos_login` WRITE;
/*!40000 ALTER TABLE `intentos_login` DISABLE KEYS */;
/*!40000 ALTER TABLE `intentos_login` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `listas_acceso_ip`
--

DROP TABLE IF EXISTS `listas_acceso_ip`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `listas_acceso_ip` (
  `id_lista` int(11) NOT NULL AUTO_INCREMENT,
  `ip` varchar(45) NOT NULL,
  `tipo_lista` enum('BLANCA','NEGRA') NOT NULL,
  `motivo` text DEFAULT NULL,
  `fecha_agregado` datetime NOT NULL DEFAULT current_timestamp(),
  `reincidencias` int(11) NOT NULL DEFAULT 1,
  `fecha_expiracion` datetime DEFAULT NULL,
  PRIMARY KEY (`id_lista`),
  UNIQUE KEY `idx_ip_unica` (`ip`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `listas_acceso_ip`
--

LOCK TABLES `listas_acceso_ip` WRITE;
/*!40000 ALTER TABLE `listas_acceso_ip` DISABLE KEYS */;
/*!40000 ALTER TABLE `listas_acceso_ip` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `modulos`
--

DROP TABLE IF EXISTS `modulos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `modulos` (
  `id_modulo` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(50) NOT NULL,
  `activo` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id_modulo`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `modulos`
--

LOCK TABLES `modulos` WRITE;
/*!40000 ALTER TABLE `modulos` DISABLE KEYS */;
INSERT INTO `modulos` VALUES (1,'GESTIONAR_PAGOS',1),(2,'GESTIONAR_GASTOS',1),(3,'GESTIONAR_MENSUALIDAD',1),(4,'GESTIONAR_CAJA_CHICA',1),(5,'GESTIONAR_CARTELERA_VIRTUAL',1),(6,'GESTIONAR_APARTAMENTOS',1),(7,'GESTIONAR_SOLICITUD_GASTO',1),(8,'GESTIONAR_PRESUPUESTO',1),(9,'GESTIONAR_ANIO_FISCAL',1),(10,'GESTIONAR_CONFIGURACION',1),(11,'GESTIONAR_PROVEEDORES',1),(12,'GESTIONAR_BANCOS',1),(13,'GESTIONAR_TIPO_GASTO',1),(14,'GESTIONAR_USUARIOS',1),(15,'GESTIONAR_REPORTES',1),(16,'GESTIONAR_SEGURIDAD',1),(17,'GESTIONAR_ROLES',1),(18,'GESTIONAR_BITACORA',1),(19,'GESTIONAR_MANTENIMIENTO',1),(21,'GESTIONAR_HABITANTES',1),(22,'GESTIONAR_PERMISOS',1),(23,'GESTIONAR_MODULOS',1);
/*!40000 ALTER TABLE `modulos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notificacion_evento`
--

DROP TABLE IF EXISTS `notificacion_evento`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `notificacion_evento` (
  `notificacion_id` int(11) NOT NULL,
  `evento_id` int(11) NOT NULL,
  PRIMARY KEY (`notificacion_id`,`evento_id`),
  KEY `evento_id` (`evento_id`),
  CONSTRAINT `notificacion_evento_ibfk_1` FOREIGN KEY (`notificacion_id`) REFERENCES `notificaciones` (`id_notificacion`) ON DELETE CASCADE,
  CONSTRAINT `notificacion_evento_ibfk_2` FOREIGN KEY (`evento_id`) REFERENCES `eventos_sistema` (`id_evento`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notificacion_evento`
--

LOCK TABLES `notificacion_evento` WRITE;
/*!40000 ALTER TABLE `notificacion_evento` DISABLE KEYS */;
INSERT INTO `notificacion_evento` VALUES (239,32),(240,32),(241,32),(242,32),(243,32),(244,32),(245,33),(246,33),(247,33),(248,33),(249,33),(250,33),(251,34),(252,34),(253,34),(254,34),(255,34),(256,34),(257,35),(258,35),(259,35),(260,35),(261,35),(262,35),(263,36),(264,36),(265,36),(266,36),(267,36),(268,36),(269,37),(270,37),(271,37),(272,37),(273,37),(274,37),(275,38),(276,38),(277,38),(278,38),(279,38),(280,38),(281,39),(282,39),(283,39),(284,39),(285,39),(286,39),(287,40),(288,40),(289,40),(290,40),(291,40),(292,40),(293,41),(294,41),(295,41),(296,41),(297,41),(298,41),(299,42),(300,42),(301,42),(302,42),(303,42),(304,42),(305,43),(306,43),(307,43),(308,43),(309,43),(310,43),(311,44),(312,44),(313,45),(314,45),(315,45),(316,45),(317,45),(318,45),(319,46),(320,46),(321,46),(322,46),(323,46),(324,46),(325,47),(326,47),(327,47),(328,47),(329,47),(330,47),(331,48),(332,48),(333,49),(334,49),(335,49),(336,49),(337,49),(338,49),(339,50),(340,50),(341,51),(342,51),(343,52),(344,52),(345,53),(346,53),(347,54),(348,54),(349,55),(350,55),(351,56),(352,56),(353,57),(354,57),(355,58),(356,58),(357,58),(358,58),(359,59),(360,59),(361,59),(362,59),(363,60),(364,60),(365,60),(366,60),(367,61),(368,61),(369,61),(370,61),(371,62),(372,62),(373,62),(374,63),(375,63),(376,63),(377,63),(378,64),(379,64),(380,64),(381,65),(382,65),(383,65),(384,65),(385,66),(386,66),(387,66),(388,67),(389,67),(390,67),(391,67),(392,68),(393,68),(394,68),(395,69),(396,69),(397,69),(398,69),(399,70),(400,70),(401,70),(402,70),(403,71),(404,71),(405,71),(406,72),(407,72),(408,72),(409,73),(410,73),(411,73),(412,74),(413,74),(414,74),(415,74),(416,75),(417,75),(418,75);
/*!40000 ALTER TABLE `notificacion_evento` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notificaciones`
--

DROP TABLE IF EXISTS `notificaciones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `notificaciones` (
  `id_notificacion` int(11) NOT NULL AUTO_INCREMENT,
  `titulo` varchar(100) NOT NULL,
  `descripcion` text NOT NULL,
  `fecha` datetime NOT NULL DEFAULT current_timestamp(),
  `leido` tinyint(1) NOT NULL,
  `usuario_id` int(11) NOT NULL,
  PRIMARY KEY (`id_notificacion`),
  KEY `notificaciones_ibfk_1` (`usuario_id`),
  CONSTRAINT `notificaciones_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id_usuario`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=419 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notificaciones`
--

LOCK TABLES `notificaciones` WRITE;
/*!40000 ALTER TABLE `notificaciones` DISABLE KEYS */;
INSERT INTO `notificaciones` VALUES (239,'Nueva mensualidad disponible','Se han generado las mensualidades para el mes 1 del año 2026.','2026-05-18 22:20:20',1,1),(240,'Nueva mensualidad disponible','Se han generado las mensualidades para el mes 1 del año 2026.','2026-05-18 22:20:20',0,2),(241,'Nueva mensualidad disponible','Se han generado las mensualidades para el mes 1 del año 2026.','2026-05-18 22:20:20',0,27),(242,'Nueva mensualidad disponible','Se han generado las mensualidades para el mes 1 del año 2026.','2026-05-18 22:20:20',0,39),(243,'Nueva mensualidad disponible','Se han generado las mensualidades para el mes 1 del año 2026.','2026-05-18 22:20:20',0,91),(244,'Nueva mensualidad disponible','Se han generado las mensualidades para el mes 1 del año 2026.','2026-05-18 22:20:20',0,92),(245,'Nueva mensualidad disponible','Se han generado las mensualidades para el mes 1 del año 2026.','2026-05-18 22:21:23',1,1),(246,'Nueva mensualidad disponible','Se han generado las mensualidades para el mes 1 del año 2026.','2026-05-18 22:21:23',0,2),(247,'Nueva mensualidad disponible','Se han generado las mensualidades para el mes 1 del año 2026.','2026-05-18 22:21:23',0,27),(248,'Nueva mensualidad disponible','Se han generado las mensualidades para el mes 1 del año 2026.','2026-05-18 22:21:23',0,39),(249,'Nueva mensualidad disponible','Se han generado las mensualidades para el mes 1 del año 2026.','2026-05-18 22:21:23',0,91),(250,'Nueva mensualidad disponible','Se han generado las mensualidades para el mes 1 del año 2026.','2026-05-18 22:21:23',0,92),(251,'Nuevo aviso: hola','muy bienas, soy una publicacion desde la web','2026-06-06 17:40:18',1,1),(252,'Nuevo aviso: hola','muy bienas, soy una publicacion desde la web','2026-06-06 17:40:18',0,2),(253,'Nuevo aviso: hola','muy bienas, soy una publicacion desde la web','2026-06-06 17:40:18',0,27),(254,'Nuevo aviso: hola','muy bienas, soy una publicacion desde la web','2026-06-06 17:40:18',0,39),(255,'Nuevo aviso: hola','muy bienas, soy una publicacion desde la web','2026-06-06 17:40:18',0,91),(256,'Nuevo aviso: hola','muy bienas, soy una publicacion desde la web','2026-06-06 17:40:18',0,92),(257,'Nuevo aviso: hola','soy una publicacion hecha por el contador francisco','2026-06-06 17:42:37',1,1),(258,'Nuevo aviso: hola','soy una publicacion hecha por el contador francisco','2026-06-06 17:42:37',0,2),(259,'Nuevo aviso: hola','soy una publicacion hecha por el contador francisco','2026-06-06 17:42:37',0,27),(260,'Nuevo aviso: hola','soy una publicacion hecha por el contador francisco','2026-06-06 17:42:37',0,39),(261,'Nuevo aviso: hola','soy una publicacion hecha por el contador francisco','2026-06-06 17:42:37',0,91),(262,'Nuevo aviso: hola','soy una publicacion hecha por el contador francisco','2026-06-06 17:42:37',0,92),(263,'Nuevo aviso: hola','soy otra publicacion de francisco','2026-06-06 17:43:52',1,1),(264,'Nuevo aviso: hola','soy otra publicacion de francisco','2026-06-06 17:43:52',0,2),(265,'Nuevo aviso: hola','soy otra publicacion de francisco','2026-06-06 17:43:52',0,27),(266,'Nuevo aviso: hola','soy otra publicacion de francisco','2026-06-06 17:43:52',0,39),(267,'Nuevo aviso: hola','soy otra publicacion de francisco','2026-06-06 17:43:52',0,91),(268,'Nuevo aviso: hola','soy otra publicacion de francisco','2026-06-06 17:43:52',0,92),(269,'Nuevo aviso: publicacion','tercera publicacion de fran','2026-06-06 18:01:14',1,1),(270,'Nuevo aviso: publicacion','tercera publicacion de fran','2026-06-06 18:01:14',0,2),(271,'Nuevo aviso: publicacion','tercera publicacion de fran','2026-06-06 18:01:14',0,27),(272,'Nuevo aviso: publicacion','tercera publicacion de fran','2026-06-06 18:01:14',0,39),(273,'Nuevo aviso: publicacion','tercera publicacion de fran','2026-06-06 18:01:15',0,91),(274,'Nuevo aviso: publicacion','tercera publicacion de fran','2026-06-06 18:01:15',0,92),(275,'Nuevo aviso: cuarta','cuarta publicacion del contador francisco','2026-06-06 18:08:23',1,1),(276,'Nuevo aviso: cuarta','cuarta publicacion del contador francisco','2026-06-06 18:08:23',0,2),(277,'Nuevo aviso: cuarta','cuarta publicacion del contador francisco','2026-06-06 18:08:23',0,27),(278,'Nuevo aviso: cuarta','cuarta publicacion del contador francisco','2026-06-06 18:08:23',0,39),(279,'Nuevo aviso: cuarta','cuarta publicacion del contador francisco','2026-06-06 18:08:23',0,91),(280,'Nuevo aviso: cuarta','cuarta publicacion del contador francisco','2026-06-06 18:08:23',0,92),(281,'Nuevo aviso: quinta','quinta publicacion de francisco','2026-06-06 18:33:31',1,1),(282,'Nuevo aviso: quinta','quinta publicacion de francisco','2026-06-06 18:33:32',0,2),(283,'Nuevo aviso: quinta','quinta publicacion de francisco','2026-06-06 18:33:32',0,27),(284,'Nuevo aviso: quinta','quinta publicacion de francisco','2026-06-06 18:33:32',0,39),(285,'Nuevo aviso: quinta','quinta publicacion de francisco','2026-06-06 18:33:32',0,91),(286,'Nuevo aviso: quinta','quinta publicacion de francisco','2026-06-06 18:33:32',0,92),(287,'Nuevo aviso: sexta','sexta publicacion de francisco','2026-06-06 18:37:37',1,1),(288,'Nuevo aviso: sexta','sexta publicacion de francisco','2026-06-06 18:37:37',0,2),(289,'Nuevo aviso: sexta','sexta publicacion de francisco','2026-06-06 18:37:37',0,27),(290,'Nuevo aviso: sexta','sexta publicacion de francisco','2026-06-06 18:37:37',0,39),(291,'Nuevo aviso: sexta','sexta publicacion de francisco','2026-06-06 18:37:37',0,91),(292,'Nuevo aviso: sexta','sexta publicacion de francisco','2026-06-06 18:37:37',0,92),(293,'Nuevo aviso: septima ','septima notificacion de francisco','2026-06-06 18:50:42',1,1),(294,'Nuevo aviso: septima ','septima notificacion de francisco','2026-06-06 18:50:42',0,2),(295,'Nuevo aviso: septima ','septima notificacion de francisco','2026-06-06 18:50:42',0,27),(296,'Nuevo aviso: septima ','septima notificacion de francisco','2026-06-06 18:50:42',0,39),(297,'Nuevo aviso: septima ','septima notificacion de francisco','2026-06-06 18:50:42',0,91),(298,'Nuevo aviso: septima ','septima notificacion de francisco','2026-06-06 18:50:42',0,92),(299,'Nuevo aviso: publicacion','publicacion del administrador','2026-06-07 17:13:02',1,1),(300,'Nuevo aviso: publicacion','publicacion del administrador','2026-06-07 17:13:02',0,2),(301,'Nuevo aviso: publicacion','publicacion del administrador','2026-06-07 17:13:02',0,27),(302,'Nuevo aviso: publicacion','publicacion del administrador','2026-06-07 17:13:02',0,39),(303,'Nuevo aviso: publicacion','publicacion del administrador','2026-06-07 17:13:02',0,91),(304,'Nuevo aviso: publicacion','publicacion del administrador','2026-06-07 17:13:02',0,92),(305,'Nuevo aviso: publicacion','publicacion del administrador','2026-06-07 17:18:43',1,1),(306,'Nuevo aviso: publicacion','publicacion del administrador','2026-06-07 17:18:43',0,2),(307,'Nuevo aviso: publicacion','publicacion del administrador','2026-06-07 17:18:43',0,27),(308,'Nuevo aviso: publicacion','publicacion del administrador','2026-06-07 17:18:43',0,39),(309,'Nuevo aviso: publicacion','publicacion del administrador','2026-06-07 17:18:43',0,91),(310,'Nuevo aviso: publicacion','publicacion del administrador','2026-06-07 17:18:43',0,92),(311,'Nuevo Pago Registrado','Se ha registrado un pago a través del portal web. Requiere revisión y aprobación.','2026-06-07 17:40:28',1,1),(312,'Nuevo Pago Registrado','Se ha registrado un pago a través del portal web. Requiere revisión y aprobación.','2026-06-07 17:40:28',0,39),(313,'Nuevo aviso: octava','octava publicacion de francico','2026-06-07 18:30:19',1,1),(314,'Nuevo aviso: octava','octava publicacion de francico','2026-06-07 18:30:19',0,2),(315,'Nuevo aviso: octava','octava publicacion de francico','2026-06-07 18:30:19',0,27),(316,'Nuevo aviso: octava','octava publicacion de francico','2026-06-07 18:30:19',0,39),(317,'Nuevo aviso: octava','octava publicacion de francico','2026-06-07 18:30:19',0,91),(318,'Nuevo aviso: octava','octava publicacion de francico','2026-06-07 18:30:19',0,92),(319,'Nuevo aviso: octava','octava publicacion de francico','2026-06-07 18:30:54',1,1),(320,'Nuevo aviso: octava','octava publicacion de francico','2026-06-07 18:30:54',0,2),(321,'Nuevo aviso: octava','octava publicacion de francico','2026-06-07 18:30:54',0,27),(322,'Nuevo aviso: octava','octava publicacion de francico','2026-06-07 18:30:54',0,39),(323,'Nuevo aviso: octava','octava publicacion de francico','2026-06-07 18:30:54',0,91),(324,'Nuevo aviso: octava','octava publicacion de francico','2026-06-07 18:30:54',0,92),(325,'Nuevo aviso: octava','octava publicacion de francico','2026-06-07 18:32:06',1,1),(326,'Nuevo aviso: octava','octava publicacion de francico','2026-06-07 18:32:06',0,2),(327,'Nuevo aviso: octava','octava publicacion de francico','2026-06-07 18:32:06',0,27),(328,'Nuevo aviso: octava','octava publicacion de francico','2026-06-07 18:32:06',0,39),(329,'Nuevo aviso: octava','octava publicacion de francico','2026-06-07 18:32:06',0,91),(330,'Nuevo aviso: octava','octava publicacion de francico','2026-06-07 18:32:06',0,92),(331,'Nuevo Pago Registrado','Requiere revisión y aprobación.','2026-06-08 11:48:18',1,1),(332,'Nuevo Pago Registrado','Requiere revisión y aprobación.','2026-06-08 11:48:18',0,39),(333,'Nuevo aviso: Atencion','Necesitamos mejorar el diseño de los detalles ','2026-06-08 12:27:52',1,1),(334,'Nuevo aviso: Atencion','Necesitamos mejorar el diseño de los detalles ','2026-06-08 12:27:52',0,2),(335,'Nuevo aviso: Atencion','Necesitamos mejorar el diseño de los detalles ','2026-06-08 12:27:52',0,27),(336,'Nuevo aviso: Atencion','Necesitamos mejorar el diseño de los detalles ','2026-06-08 12:27:52',0,39),(337,'Nuevo aviso: Atencion','Necesitamos mejorar el diseño de los detalles ','2026-06-08 12:27:52',0,91),(338,'Nuevo aviso: Atencion','Necesitamos mejorar el diseño de los detalles ','2026-06-08 12:27:52',0,92),(339,'Nuevo Pago Registrado','Requiere revisión y aprobación.','2026-06-08 18:35:23',1,1),(340,'Nuevo Pago Registrado','Requiere revisión y aprobación.','2026-06-08 18:35:23',0,39),(341,'Nuevo Pago Registrado','Requiere revisión y aprobación.','2026-06-08 18:40:15',1,1),(342,'Nuevo Pago Registrado','Requiere revisión y aprobación.','2026-06-08 18:40:15',0,39),(343,'Nuevo Pago Registrado','Requiere revisión y aprobación.','2026-06-08 18:41:36',1,1),(344,'Nuevo Pago Registrado','Requiere revisión y aprobación.','2026-06-08 18:41:36',0,39),(345,'Nuevo Pago Registrado','Requiere revisión y aprobación.','2026-06-08 18:50:44',1,1),(346,'Nuevo Pago Registrado','Requiere revisión y aprobación.','2026-06-08 18:50:44',0,39),(347,'Nuevo Pago Registrado','Requiere revisión y aprobación.','2026-06-08 18:51:33',1,1),(348,'Nuevo Pago Registrado','Requiere revisión y aprobación.','2026-06-08 18:51:33',0,39),(349,'Nuevo Pago Registrado','Requiere revisión y aprobación.','2026-06-08 18:56:35',1,1),(350,'Nuevo Pago Registrado','Requiere revisión y aprobación.','2026-06-08 18:56:35',0,39),(351,'Nuevo Pago Registrado','Requiere revisión y aprobación.','2026-06-08 19:00:06',1,1),(352,'Nuevo Pago Registrado','Requiere revisión y aprobación.','2026-06-08 19:00:06',0,39),(353,'Nuevo Pago Registrado','Requiere revisión y aprobación.','2026-06-08 19:00:33',1,1),(354,'Nuevo Pago Registrado','Requiere revisión y aprobación.','2026-06-08 19:00:33',0,39),(355,'Nueva Mensualidad Generada','Se ha publicado el recibo de condominio correspondiente a este mes. (1 del año 2026.)','2026-06-19 16:23:02',1,1),(356,'Nueva Mensualidad Generada','Se ha publicado el recibo de condominio correspondiente a este mes. (1 del año 2026.)','2026-06-19 16:23:02',0,2),(357,'Nueva Mensualidad Generada','Se ha publicado el recibo de condominio correspondiente a este mes. (1 del año 2026.)','2026-06-19 16:23:02',0,27),(358,'Nueva Mensualidad Generada','Se ha publicado el recibo de condominio correspondiente a este mes. (1 del año 2026.)','2026-06-19 16:23:02',0,94),(359,'Nueva Mensualidad Generada','Se ha publicado el recibo de condominio correspondiente a este mes. (1 del año 2026.)','2026-06-19 17:12:54',1,1),(360,'Nueva Mensualidad Generada','Se ha publicado el recibo de condominio correspondiente a este mes. (1 del año 2026.)','2026-06-19 17:12:54',0,2),(361,'Nueva Mensualidad Generada','Se ha publicado el recibo de condominio correspondiente a este mes. (1 del año 2026.)','2026-06-19 17:12:54',0,27),(362,'Nueva Mensualidad Generada','Se ha publicado el recibo de condominio correspondiente a este mes. (1 del año 2026.)','2026-06-19 17:12:54',0,94),(363,'Nueva Mensualidad Generada','Se ha publicado el recibo de condominio correspondiente a este mes. (3 del año 2026.)','2026-06-19 17:13:17',1,1),(364,'Nueva Mensualidad Generada','Se ha publicado el recibo de condominio correspondiente a este mes. (3 del año 2026.)','2026-06-19 17:13:17',0,2),(365,'Nueva Mensualidad Generada','Se ha publicado el recibo de condominio correspondiente a este mes. (3 del año 2026.)','2026-06-19 17:13:17',0,27),(366,'Nueva Mensualidad Generada','Se ha publicado el recibo de condominio correspondiente a este mes. (3 del año 2026.)','2026-06-19 17:13:17',0,94),(367,'Nueva Mensualidad Generada','Se ha publicado el recibo de condominio correspondiente a este mes. (4 del año 2026.)','2026-06-20 17:59:31',1,1),(368,'Nueva Mensualidad Generada','Se ha publicado el recibo de condominio correspondiente a este mes. (4 del año 2026.)','2026-06-20 17:59:31',0,2),(369,'Nueva Mensualidad Generada','Se ha publicado el recibo de condominio correspondiente a este mes. (4 del año 2026.)','2026-06-20 17:59:31',0,27),(370,'Nueva Mensualidad Generada','Se ha publicado el recibo de condominio correspondiente a este mes. (4 del año 2026.)','2026-06-20 17:59:31',0,94),(371,'Nuevo Pago Registrado','Requiere revisión y aprobación.','2026-06-20 18:02:28',1,1),(372,'Nuevo Pago Registrado','Requiere revisión y aprobación.','2026-06-20 18:02:28',0,2),(373,'Nuevo Pago Registrado','Requiere revisión y aprobación.','2026-06-20 18:02:28',0,94),(374,'Nueva Mensualidad Generada','Se ha publicado el recibo de condominio correspondiente a este mes. (5 del año 2026.)','2026-06-20 18:17:04',1,1),(375,'Nueva Mensualidad Generada','Se ha publicado el recibo de condominio correspondiente a este mes. (5 del año 2026.)','2026-06-20 18:17:04',0,2),(376,'Nueva Mensualidad Generada','Se ha publicado el recibo de condominio correspondiente a este mes. (5 del año 2026.)','2026-06-20 18:17:04',0,27),(377,'Nueva Mensualidad Generada','Se ha publicado el recibo de condominio correspondiente a este mes. (5 del año 2026.)','2026-06-20 18:17:04',0,94),(378,'Nuevo Pago Registrado','Requiere revisión y aprobación.','2026-06-20 18:18:00',1,1),(379,'Nuevo Pago Registrado','Requiere revisión y aprobación.','2026-06-20 18:18:00',0,2),(380,'Nuevo Pago Registrado','Requiere revisión y aprobación.','2026-06-20 18:18:00',0,94),(381,'Nueva Mensualidad Generada','Se ha publicado el recibo de condominio correspondiente a este mes. (5 del año 2026.)','2026-06-20 18:19:25',1,1),(382,'Nueva Mensualidad Generada','Se ha publicado el recibo de condominio correspondiente a este mes. (5 del año 2026.)','2026-06-20 18:19:25',0,2),(383,'Nueva Mensualidad Generada','Se ha publicado el recibo de condominio correspondiente a este mes. (5 del año 2026.)','2026-06-20 18:19:25',0,27),(384,'Nueva Mensualidad Generada','Se ha publicado el recibo de condominio correspondiente a este mes. (5 del año 2026.)','2026-06-20 18:19:25',0,94),(385,'Nuevo Pago Registrado','Requiere revisión y aprobación.','2026-06-20 18:21:04',1,1),(386,'Nuevo Pago Registrado','Requiere revisión y aprobación.','2026-06-20 18:21:04',0,2),(387,'Nuevo Pago Registrado','Requiere revisión y aprobación.','2026-06-20 18:21:04',0,94),(388,'Nueva Mensualidad Generada','Se ha publicado el recibo de condominio correspondiente a este mes. (5 del año 2026.)','2026-06-20 18:24:45',1,1),(389,'Nueva Mensualidad Generada','Se ha publicado el recibo de condominio correspondiente a este mes. (5 del año 2026.)','2026-06-20 18:24:45',0,2),(390,'Nueva Mensualidad Generada','Se ha publicado el recibo de condominio correspondiente a este mes. (5 del año 2026.)','2026-06-20 18:24:45',0,27),(391,'Nueva Mensualidad Generada','Se ha publicado el recibo de condominio correspondiente a este mes. (5 del año 2026.)','2026-06-20 18:24:45',0,94),(392,'Nuevo Pago Registrado','Requiere revisión y aprobación.','2026-06-20 18:25:10',1,1),(393,'Nuevo Pago Registrado','Requiere revisión y aprobación.','2026-06-20 18:25:10',0,2),(394,'Nuevo Pago Registrado','Requiere revisión y aprobación.','2026-06-20 18:25:10',0,94),(395,'Nueva Mensualidad Generada','Se ha publicado el recibo de condominio correspondiente a este mes. (5 del año 2026.)','2026-06-21 17:39:07',1,1),(396,'Nueva Mensualidad Generada','Se ha publicado el recibo de condominio correspondiente a este mes. (5 del año 2026.)','2026-06-21 17:39:07',0,2),(397,'Nueva Mensualidad Generada','Se ha publicado el recibo de condominio correspondiente a este mes. (5 del año 2026.)','2026-06-21 17:39:07',0,27),(398,'Nueva Mensualidad Generada','Se ha publicado el recibo de condominio correspondiente a este mes. (5 del año 2026.)','2026-06-21 17:39:07',0,94),(399,'Nueva Mensualidad Generada','Se ha publicado el recibo de condominio correspondiente a este mes. (5 del año 2026.)','2026-06-21 17:49:47',1,1),(400,'Nueva Mensualidad Generada','Se ha publicado el recibo de condominio correspondiente a este mes. (5 del año 2026.)','2026-06-21 17:49:47',0,2),(401,'Nueva Mensualidad Generada','Se ha publicado el recibo de condominio correspondiente a este mes. (5 del año 2026.)','2026-06-21 17:49:47',0,27),(402,'Nueva Mensualidad Generada','Se ha publicado el recibo de condominio correspondiente a este mes. (5 del año 2026.)','2026-06-21 17:49:47',0,94),(403,'Nuevo Pago Registrado','Requiere revisión y aprobación.','2026-06-21 17:52:30',1,1),(404,'Nuevo Pago Registrado','Requiere revisión y aprobación.','2026-06-21 17:52:30',0,2),(405,'Nuevo Pago Registrado','Requiere revisión y aprobación.','2026-06-21 17:52:30',0,94),(406,'Nuevo Pago Registrado','Requiere revisión y aprobación.','2026-06-21 19:03:53',0,1),(407,'Nuevo Pago Registrado','Requiere revisión y aprobación.','2026-06-21 19:03:53',0,2),(408,'Nuevo Pago Registrado','Requiere revisión y aprobación.','2026-06-21 19:03:53',0,94),(409,'Nuevo Pago Registrado','Requiere revisión y aprobación.','2026-06-21 19:18:06',0,1),(410,'Nuevo Pago Registrado','Requiere revisión y aprobación.','2026-06-21 19:18:06',0,2),(411,'Nuevo Pago Registrado','Requiere revisión y aprobación.','2026-06-21 19:18:06',0,94),(412,'Nueva Mensualidad Generada','Se ha publicado el recibo de condominio correspondiente a este mes. (1 del año 2026.)','2026-06-21 19:26:57',0,1),(413,'Nueva Mensualidad Generada','Se ha publicado el recibo de condominio correspondiente a este mes. (1 del año 2026.)','2026-06-21 19:26:57',0,2),(414,'Nueva Mensualidad Generada','Se ha publicado el recibo de condominio correspondiente a este mes. (1 del año 2026.)','2026-06-21 19:26:57',0,27),(415,'Nueva Mensualidad Generada','Se ha publicado el recibo de condominio correspondiente a este mes. (1 del año 2026.)','2026-06-21 19:26:57',0,94),(416,'Nuevo Pago Registrado','Requiere revisión y aprobación.','2026-06-21 19:27:21',0,1),(417,'Nuevo Pago Registrado','Requiere revisión y aprobación.','2026-06-21 19:27:21',0,2),(418,'Nuevo Pago Registrado','Requiere revisión y aprobación.','2026-06-21 19:27:21',0,94);
/*!40000 ALTER TABLE `notificaciones` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `permisos`
--

DROP TABLE IF EXISTS `permisos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `permisos` (
  `id_permiso` int(11) NOT NULL AUTO_INCREMENT,
  `accion` varchar(50) NOT NULL,
  `activo` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id_permiso`)
) ENGINE=InnoDB AUTO_INCREMENT=91 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permisos`
--

LOCK TABLES `permisos` WRITE;
/*!40000 ALTER TABLE `permisos` DISABLE KEYS */;
INSERT INTO `permisos` VALUES (1,'REGISTRAR',1),(2,'CONSULTAR',1),(3,'MODIFICAR',1),(4,'ELIMINAR',1);
/*!40000 ALTER TABLE `permisos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `registro_ips`
--

DROP TABLE IF EXISTS `registro_ips`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `registro_ips` (
  `ip` varchar(45) NOT NULL,
  `intentos` int(11) NOT NULL DEFAULT 1,
  `ultimo_intento` datetime NOT NULL DEFAULT current_timestamp(),
  `infracciones` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`ip`)
) ENGINE=MEMORY DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `registro_ips`
--

LOCK TABLES `registro_ips` WRITE;
/*!40000 ALTER TABLE `registro_ips` DISABLE KEYS */;
INSERT INTO `registro_ips` VALUES ('127.0.0.1',33,'2026-06-22 19:06:27',0);
/*!40000 ALTER TABLE `registro_ips` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `roles` (
  `id_rol` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(50) NOT NULL,
  `activo` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id_rol`),
  UNIQUE KEY `nombre` (`nombre`)
) ENGINE=InnoDB AUTO_INCREMENT=73 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles`
--

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES (1,'Administrador Global',1),(2,'Administrador',1),(3,'Propietario',1),(4,'Contador',1),(23,'Presidente',1);
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `suscripciones_push`
--

DROP TABLE IF EXISTS `suscripciones_push`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `suscripciones_push` (
  `id_suscripcion` int(11) NOT NULL AUTO_INCREMENT,
  `usuario_id` int(11) NOT NULL,
  `endpoint` text NOT NULL,
  `p256dh` varchar(255) NOT NULL,
  `auth` varchar(255) NOT NULL,
  `fecha_registro` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id_suscripcion`),
  KEY `suscripciones_push_ibfk_1` (`usuario_id`),
  CONSTRAINT `suscripciones_push_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id_usuario`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `suscripciones_push`
--

LOCK TABLES `suscripciones_push` WRITE;
/*!40000 ALTER TABLE `suscripciones_push` DISABLE KEYS */;
INSERT INTO `suscripciones_push` VALUES (1,1,'https://updates.push.services.mozilla.com/wpush/v2/gAAAAABp1ZseTDQjnU5lI9AUO3eTuNHUP_qj8r1xvlJZs3h9TYmjAETOu3DuVzspQCdWsiH1pXGvZE-ofcigSRPYAYj1JhNSe2Dzmp4MSjmvDKvZQeYV00zfaXuyZ-WNy0madX2qSkqrBRjsB_UrzgsBcc-h7MAdL41G3cQrc5fY6i7HsVaJD7k','BPSoziQjJfxaG05/wBlvkgZ+XmfRZI/7Wnjw48WyE3qDOKayqeoGLQYihJM7KtCUDASM4Rv43HTvx7CSINbphkE=','dVIKY/GHisXcOM5xCM90ww==','2026-04-07 22:45:44');
/*!40000 ALTER TABLE `suscripciones_push` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `suscripciones_push_movil`
--

DROP TABLE IF EXISTS `suscripciones_push_movil`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `suscripciones_push_movil` (
  `id_suscripcion_movil` int(11) NOT NULL AUTO_INCREMENT,
  `usuario_id` int(11) NOT NULL,
  `expo_token` varchar(255) NOT NULL,
  `plataforma` enum('ANDROID','IOS') NOT NULL,
  `fecha_registro` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id_suscripcion_movil`),
  UNIQUE KEY `expo_token_unico` (`expo_token`),
  KEY `fk_suscripcion_movil_usuario` (`usuario_id`),
  CONSTRAINT `fk_suscripcion_movil_usuario` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id_usuario`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `suscripciones_push_movil`
--

LOCK TABLES `suscripciones_push_movil` WRITE;
/*!40000 ALTER TABLE `suscripciones_push_movil` DISABLE KEYS */;
INSERT INTO `suscripciones_push_movil` VALUES (1,1,'ExponentPushToken[5u-wmJMB4mrfEUwdS58JX_]','ANDROID','2026-06-06 21:37:20'),(2,1,'ExponentPushToken[hdEzyaMoeVaN5ruVlBcXqm]','ANDROID','2026-06-12 21:22:07');
/*!40000 ALTER TABLE `suscripciones_push_movil` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tokens_seguridad`
--

DROP TABLE IF EXISTS `tokens_seguridad`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tokens_seguridad` (
  `id_token` int(11) NOT NULL AUTO_INCREMENT,
  `usuario_id` int(11) NOT NULL,
  `token` text NOT NULL,
  `fecha_expiracion` datetime NOT NULL,
  `tipo` varchar(30) NOT NULL,
  PRIMARY KEY (`id_token`),
  KEY `usuario_id` (`usuario_id`),
  CONSTRAINT `tokens_seguridad_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id_usuario`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=310 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tokens_seguridad`
--

LOCK TABLES `tokens_seguridad` WRITE;
/*!40000 ALTER TABLE `tokens_seguridad` DISABLE KEYS */;
INSERT INTO `tokens_seguridad` VALUES (292,27,'746720dd632b9db52c35c86e4fbaf2ccae892e5c104fde2d47e2c43808a1f749','2026-07-04 02:42:47','REFRESH_TOKEN_MOVIL'),(306,1,'e036cee2293f4967487823569b098110f985bee6b9a32b61593757182bb0ddcf','2026-07-14 15:36:20','REFRESH_TOKEN_MOVIL');
/*!40000 ALTER TABLE `tokens_seguridad` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trafico_usuarios`
--

DROP TABLE IF EXISTS `trafico_usuarios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trafico_usuarios` (
  `usuario_id` int(11) NOT NULL,
  `peticiones` int(11) NOT NULL DEFAULT 1,
  `ultimo_intento` datetime NOT NULL,
  PRIMARY KEY (`usuario_id`)
) ENGINE=MEMORY DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trafico_usuarios`
--

LOCK TABLES `trafico_usuarios` WRITE;
/*!40000 ALTER TABLE `trafico_usuarios` DISABLE KEYS */;
INSERT INTO `trafico_usuarios` VALUES (1,33,'2026-06-22 19:06:27');
/*!40000 ALTER TABLE `trafico_usuarios` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usuarios`
--

DROP TABLE IF EXISTS `usuarios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `usuarios` (
  `id_usuario` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(50) NOT NULL,
  `apellido` varchar(50) NOT NULL,
  `correo` varchar(100) NOT NULL,
  `contrasenia` varchar(255) NOT NULL,
  `rol_id` int(11) NOT NULL,
  `activo` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id_usuario`),
  UNIQUE KEY `correo` (`correo`),
  KEY `usuarios_ibfk_1` (`rol_id`),
  CONSTRAINT `usuarios_ibfk_1` FOREIGN KEY (`rol_id`) REFERENCES `roles` (`id_rol`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=95 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuarios`
--

LOCK TABLES `usuarios` WRITE;
/*!40000 ALTER TABLE `usuarios` DISABLE KEYS */;
INSERT INTO `usuarios` VALUES (1,'Jesus','Escalona','administrador@gmail.com','$2y$10$PSQuQ6JSX.UcGDlV8w4oauDJkL9o7d06f7AFZc4QCH9xAd2VSHA/G',1,1),(2,'Francisco','Mendoza','franj@gmail.com','$2y$10$eNXBkMmHbpbQkZaXfrSMIuYl86s/wlFmdzw/0kLwsfKd66NVT5JLC',1,1),(27,'Pepes','Campos','pepe@gmail.com','$2y$10$WWp8M1SADJzTWAg910K.mewfZFglQF77ENnqPYLmq1U9AKmmeruY2',3,1),(39,'Yhsius','asdasd','jesusgescalonae@gmail.com','$2y$10$o5jicwKwqPcPyZmciN/pvOokS9MSOUghVCZMB5aHh3YQ3qZ5oSs8G',2,0),(53,'perfil editado','perfil editado','UsuarioperfilEditada@gmail.com','$2y$10$AzKv19h61AeAkEYPA/FSA.buvyhYKoRfHT/kUFgMDSWE11PKjpBLS',4,0),(54,'usuario','cambiocontra','cambiocontrasenia@gmail.com','$2y$10$soYFxka95IzptEPe5eA.IONdFJI/geOcpt0K/L7aAKNIsTyn.5Nd2',23,0),(89,'pepe','puias','pepa@gmail.com','$2y$10$GtV9.reiR/8A/NindSEEUOtCPjAs.lLxS67Qp9ZNtG6Ug3wzd5nXi',1,0),(90,'asdasd','asdasd','asdas@ad.com','$2y$10$tTc2q0y3G8sZ8glF3vyDiO.b3DqLtm/TJ/HTJl8QZM2pforDC0TdO',1,0),(91,'test','test','test@gmail.com','$2y$10$M/b/1lwlXVk7g0bHNfBiIOZ1XM0OQIB6SU5GPG2SL0JnhTQvD4Dqu',69,0),(92,'presi','presi','presi@gmail.com','$2y$10$mE8PllA/a3G4ecc.UIZi4u9771m5QBZ3vk/7jWRutkQooM5rD1ryG',23,0),(93,'test','test','tests@gmail.com','$2y$10$apVDsr/j3IR3lOovWTAgje3Czb4e1mmPXBAedAzQnkvGD1PVkF9ia',4,0),(94,'Rafael','Gutiérrez','admin@gmail.com','$2y$10$UW7IeCBVeWrc3I.hGlWprehTmt/O9aCpKhQo6Q1ZKeHshKdyLMQNa',1,1);
/*!40000 ALTER TABLE `usuarios` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `vw_perfiles_usuarios`
--

DROP TABLE IF EXISTS `vw_perfiles_usuarios`;
/*!50001 DROP VIEW IF EXISTS `vw_perfiles_usuarios`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `vw_perfiles_usuarios` AS SELECT
 1 AS `id_usuario`,
  1 AS `nombre`,
  1 AS `apellido`,
  1 AS `correo`,
  1 AS `contrasenia`,
  1 AS `activo`,
  1 AS `rol_id`,
  1 AS `nombre_rol` */;
SET character_set_client = @saved_cs_client;

--
-- Dumping events for database 'seguridad_haydee_db'
--

--
-- Dumping routines for database 'seguridad_haydee_db'
--
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_VALUE_ON_ZERO' */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_insertar_token` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
DELIMITER ;;
CREATE PROCEDURE `sp_insertar_token`(IN `p_usuario_id` INT(11), IN `p_tipo` VARCHAR(30), IN `p_token` TEXT, IN `p_fecha_expiracion` DATETIME)
BEGIN

    
    
    DECLARE EXIT HANDLER FOR SQLEXCEPTION

    BEGIN

        ROLLBACK;

        RESIGNAL; 

    END;



    
    START TRANSACTION;



    
    
    DELETE FROM tokens_seguridad 

    WHERE usuario_id = p_usuario_id AND fecha_expiracion < NOW();



    
    
    
    DELETE FROM tokens_seguridad 

    WHERE usuario_id = p_usuario_id AND tipo = p_tipo;



    
    INSERT INTO tokens_seguridad (

        usuario_id, 

        tipo, 

        token, 

        fecha_expiracion

    ) VALUES (

        p_usuario_id, 

        p_tipo, 

        p_token, 

        p_fecha_expiracion

    );



    
    COMMIT;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_VALUE_ON_ZERO' */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_notificar_administradores` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
DELIMITER ;;
CREATE PROCEDURE `sp_notificar_administradores`(IN `p_tit` VARCHAR(100), IN `p_desc` TEXT, IN `p_tabla` VARCHAR(50), IN `p_id_reg` INT, IN `p_tipo` VARCHAR(50))
BEGIN

    DECLARE v_evento_id INT;

    DECLARE v_admin_id INT;

    DECLARE v_notif_id INT;

    DECLARE v_done INT DEFAULT FALSE;

    

    
    DECLARE cur_admins CURSOR FOR 

        SELECT id_usuario FROM usuarios WHERE rol_id IN (1, 2) AND activo = 1;

        

    DECLARE CONTINUE HANDLER FOR NOT FOUND SET v_done = TRUE;

    

    DECLARE EXIT HANDLER FOR SQLEXCEPTION

    BEGIN

        ROLLBACK;

    END;



    START TRANSACTION;



    
    INSERT INTO eventos_sistema (tipo_evento, tabla_origen, id_registro_origen, fecha_evento)

    VALUES (p_tipo, p_tabla, p_id_reg, NOW());

    

    SET v_evento_id = LAST_INSERT_ID();



    
    OPEN cur_admins;

    

    read_loop: LOOP

        FETCH cur_admins INTO v_admin_id;

        IF v_done THEN

            LEAVE read_loop;

        END IF;



        
        INSERT INTO notificaciones (titulo, descripcion, fecha, leido, usuario_id)

        VALUES (p_tit, p_desc, NOW(), 0, v_admin_id);

        

        SET v_notif_id = LAST_INSERT_ID();



        
        INSERT INTO notificacion_evento (notificacion_id, evento_id)

        VALUES (v_notif_id, v_evento_id);

        

    END LOOP;

    

    CLOSE cur_admins;



    COMMIT;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Final view structure for view `vw_perfiles_usuarios`
--

/*!50001 DROP VIEW IF EXISTS `vw_perfiles_usuarios`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 SQL SECURITY DEFINER */
/*!50001 VIEW `vw_perfiles_usuarios` AS select `u`.`id_usuario` AS `id_usuario`,`u`.`nombre` AS `nombre`,`u`.`apellido` AS `apellido`,`u`.`correo` AS `correo`,`u`.`contrasenia` AS `contrasenia`,`u`.`activo` AS `activo`,`u`.`rol_id` AS `rol_id`,`r`.`nombre` AS `nombre_rol` from (`usuarios` `u` join `roles` `r` on(`u`.`rol_id` = `r`.`id_rol`)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-06-22 19:07:12
