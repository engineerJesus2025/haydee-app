-- MariaDB dump 10.19  Distrib 10.4.32-MariaDB, for Win64 (AMD64)
--
-- Host: localhost    Database: haydee_db
-- ------------------------------------------------------
-- Server version	10.4.32-MariaDB-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `anio_fiscal`
--

DROP TABLE IF EXISTS `anio_fiscal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `anio_fiscal` (
  `id_anio_fiscal` int(11) NOT NULL AUTO_INCREMENT,
  `estado` varchar(20) NOT NULL,
  `fecha_inicio` date NOT NULL,
  `fecha_cierre` date NOT NULL,
  `descripcion` text NOT NULL DEFAULT 'Sin descripción',
  `activo` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id_anio_fiscal`)
) ENGINE=InnoDB AUTO_INCREMENT=65 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `anio_fiscal`
--

LOCK TABLES `anio_fiscal` WRITE;
/*!40000 ALTER TABLE `anio_fiscal` DISABLE KEYS */;
INSERT INTO `anio_fiscal` VALUES (47,'ABIERTO','2026-02-07','2027-02-07','Año fiscal 2026',1);
/*!40000 ALTER TABLE `anio_fiscal` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `apartamentos`
--

DROP TABLE IF EXISTS `apartamentos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `apartamentos` (
  `id_apartamento` int(11) NOT NULL AUTO_INCREMENT,
  `nro_apartamento` varchar(5) NOT NULL,
  `porcentaje_participacion` decimal(5,2) NOT NULL,
  `gas` tinyint(1) NOT NULL,
  `agua` tinyint(1) NOT NULL,
  `alquilado` tinyint(1) NOT NULL,
  `activo` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id_apartamento`)
) ENGINE=InnoDB AUTO_INCREMENT=43 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `apartamentos`
--

LOCK TABLES `apartamentos` WRITE;
/*!40000 ALTER TABLE `apartamentos` DISABLE KEYS */;
INSERT INTO `apartamentos` VALUES (30,'1-1',22.00,2,1,2,1),(31,'2-1',23.00,1,1,1,1),(32,'1-2',1.00,2,1,1,1),(33,'12',23.00,1,1,1,0),(35,'2-2',5.00,2,1,1,1),(37,'3-2',5.00,1,1,2,1),(39,'3-1',1.00,2,1,1,1),(41,'4-1',5.00,1,1,1,1),(42,'4-2',5.25,2,2,2,1);
/*!40000 ALTER TABLE `apartamentos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bancos`
--

DROP TABLE IF EXISTS `bancos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bancos` (
  `id_banco` int(11) NOT NULL AUTO_INCREMENT,
  `nombre_banco` varchar(50) NOT NULL,
  `codigo` varchar(7) NOT NULL,
  `numero_cuenta` varchar(50) NOT NULL,
  `tipo_cuenta` varchar(30) NOT NULL,
  `telefono_afiliado` varchar(20) NOT NULL,
  `rif` varchar(30) NOT NULL,
  `activo` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id_banco`),
  UNIQUE KEY `numero_cuenta` (`numero_cuenta`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bancos`
--

LOCK TABLES `bancos` WRITE;
/*!40000 ALTER TABLE `bancos` DISABLE KEYS */;
INSERT INTO `bancos` VALUES (1,'venezuela','0102','0102123412124232323','Ahorro','04152456842','J3232421',1),(6,'Banesco','0117','1242342342424121211','Corriente','04142584985','V5464565',1);
/*!40000 ALTER TABLE `bancos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `caja_chica`
--

DROP TABLE IF EXISTS `caja_chica`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `caja_chica` (
  `id_caja_chica` int(11) NOT NULL AUTO_INCREMENT,
  `fondo_fijo` decimal(15,2) NOT NULL,
  `estado` varchar(20) NOT NULL,
  `descripcion` text NOT NULL DEFAULT 'Sin descripción',
  `fecha_creacion` date NOT NULL DEFAULT current_timestamp(),
  `anio_fiscal_id` int(11) NOT NULL,
  `activo` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id_caja_chica`),
  KEY `anio_fiscal_id` (`anio_fiscal_id`),
  CONSTRAINT `caja_chica_ibfk_1` FOREIGN KEY (`anio_fiscal_id`) REFERENCES `anio_fiscal` (`id_anio_fiscal`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `caja_chica`
--

LOCK TABLES `caja_chica` WRITE;
/*!40000 ALTER TABLE `caja_chica` DISABLE KEYS */;
INSERT INTO `caja_chica` VALUES (30,6073.92,'Abierto','caja chica 2026','2026-06-20',47,1);
/*!40000 ALTER TABLE `caja_chica` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `detalles_gastos`
--

DROP TABLE IF EXISTS `detalles_gastos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `detalles_gastos` (
  `id_detalle_gasto` int(11) NOT NULL AUTO_INCREMENT,
  `fecha` date NOT NULL,
  `monto` decimal(15,2) NOT NULL,
  `metodo_pago` varchar(20) NOT NULL,
  `gasto_id` int(11) NOT NULL,
  PRIMARY KEY (`id_detalle_gasto`),
  KEY `gasto_id` (`gasto_id`),
  CONSTRAINT `detalles_gastos_ibfk_1` FOREIGN KEY (`gasto_id`) REFERENCES `gastos` (`id_gasto`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2057 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `detalles_gastos`
--

LOCK TABLES `detalles_gastos` WRITE;
/*!40000 ALTER TABLE `detalles_gastos` DISABLE KEYS */;
/*!40000 ALTER TABLE `detalles_gastos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `detalles_pagos`
--

DROP TABLE IF EXISTS `detalles_pagos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `detalles_pagos` (
  `id_detalle_pago` int(11) NOT NULL AUTO_INCREMENT,
  `fecha` date NOT NULL,
  `monto` decimal(15,2) NOT NULL,
  `tipo_pago` varchar(20) NOT NULL,
  `pago_id` int(11) NOT NULL,
  PRIMARY KEY (`id_detalle_pago`),
  KEY `detalles_pagos_ibfk_1` (`pago_id`),
  KEY `idx_pago_fecha` (`pago_id`,`fecha`),
  CONSTRAINT `detalles_pagos_ibfk_1` FOREIGN KEY (`pago_id`) REFERENCES `pagos` (`id_pago`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=1091 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `detalles_pagos`
--

LOCK TABLES `detalles_pagos` WRITE;
/*!40000 ALTER TABLE `detalles_pagos` DISABLE KEYS */;
INSERT INTO `detalles_pagos` VALUES (1089,'2026-06-05',10.00,'EFECTIVO',170),(1090,'2026-06-21',10.00,'EFECTIVO',171);
/*!40000 ALTER TABLE `detalles_pagos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `detalles_presupuesto`
--

DROP TABLE IF EXISTS `detalles_presupuesto`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `detalles_presupuesto` (
  `id_detalle_presupuesto` int(11) NOT NULL AUTO_INCREMENT,
  `monto` decimal(15,2) NOT NULL,
  `nombre_detalle` varchar(50) NOT NULL,
  `presupuesto_id` int(11) NOT NULL,
  `tipo_gasto_id` int(11) NOT NULL,
  PRIMARY KEY (`id_detalle_presupuesto`),
  KEY `presupuesto_id` (`presupuesto_id`),
  KEY `tipo_gasto_id` (`tipo_gasto_id`),
  CONSTRAINT `detalles_presupuesto_ibfk_1` FOREIGN KEY (`presupuesto_id`) REFERENCES `presupuesto` (`id_presupuesto`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `detalles_presupuesto_ibfk_2` FOREIGN KEY (`tipo_gasto_id`) REFERENCES `tipo_gasto` (`id_tipo_gasto`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=1453 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `detalles_presupuesto`
--

LOCK TABLES `detalles_presupuesto` WRITE;
/*!40000 ALTER TABLE `detalles_presupuesto` DISABLE KEYS */;
INSERT INTO `detalles_presupuesto` VALUES (1327,15.00,'CORPOELEC',106,2),(1328,12.00,'HIDROLARA',106,2),(1329,100.00,'Trabajadora Residencial',106,3),(1330,100.00,'Bono de alimentacion',106,3),(1331,100.00,'Bono de ayuda',106,3),(1332,100.00,'Seguridad Social',106,3),(1333,100.00,'Mantenimiento ascensor',106,4),(1334,100.00,'GAS LARA',106,5),(1335,100.00,'Bolsas de Basura',106,9),(1336,100.00,'Productos de Limpieza',106,9),(1337,100.00,'Comisiones Bancarias',106,10),(1338,100.00,'Exencion cuota del administrador',106,10),(1351,23.00,'CORPOELEC',107,2),(1352,15.00,'HIDROLARA',107,2),(1353,233.00,'Trabajadora Residencial',107,3),(1354,12.00,'Bono de alimentacion',107,3),(1355,12.00,'Bono de ayuda',107,3),(1356,100.00,'Seguridad Social',107,3),(1357,12.00,'Mantenimiento ascensor',107,4),(1358,200.00,'GAS LARA',107,5),(1359,20.00,'Bolsas de Basura',107,9),(1360,200.00,'Productos de Limpieza',107,9),(1361,200.00,'Comisiones Bancarias',107,10),(1362,200.00,'Exencion cuota del administrador',107,10),(1387,12.00,'Exencion cuota del administrador',110,10),(1388,10.00,'CORPOELEC',111,2),(1389,5.00,'HIDROLARA',111,2),(1390,123.00,'Trabajadora Residencial',111,3),(1391,15.00,'Bono de alimentacion',111,3),(1392,123.00,'Bono de ayuda',111,3),(1393,15.00,'Seguridad Social',111,3),(1394,12.00,'Mantenimiento ascensor',111,4),(1395,23.00,'GAS LARA',111,5),(1396,51.00,'Bolsas de Basura',111,9),(1397,12.00,'Productos de Limpieza',111,9),(1398,10.00,'Comisiones Bancarias',111,10),(1399,21.00,'Exencion cuota del administrador',111,10),(1424,10.00,'CORPOELEC',112,2),(1425,20.00,'HIDROLARA',112,2),(1426,50.00,'Trabajadora Residencial',112,3),(1427,10.00,'Bono de alimentacion',112,3),(1428,60.00,'Bono de ayuda',112,3),(1429,50.00,'Seguridad Social',112,3),(1430,85.00,'Mantenimiento ascensor',112,4),(1431,78.00,'GAS LARA',112,5),(1432,100.00,'Bolsas de Basura',112,9),(1433,100.00,'Productos de Limpieza',112,9),(1434,100.00,'Comisiones Bancarias',112,10),(1435,100.00,'Exencion cuota del administrador',112,10),(1439,60739.00,'CORPOELEC',113,2),(1440,12.00,'HIDROLARA',113,2),(1441,10.00,'CORPOELEC',114,2),(1442,10.00,'HIDROLARA',114,2),(1443,10.00,'Trabajadora Residencial',114,3),(1444,10.00,'Bono de alimentacion',114,3),(1445,10.00,'Bono de ayuda',114,3),(1446,90.00,'Seguridad Social',114,3),(1447,90.00,'Mantenimiento ascensor',114,4),(1448,90.00,'GAS LARA',114,5),(1449,90.00,'Bolsas de Basura',114,9),(1450,90.00,'Productos de Limpieza',114,9),(1451,90.00,'Comisiones Bancarias',114,10),(1452,90.00,'Exencion cuota del administrador',114,10);
/*!40000 ALTER TABLE `detalles_presupuesto` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `egresos_bancarios`
--

DROP TABLE IF EXISTS `egresos_bancarios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `egresos_bancarios` (
  `referencia` varchar(20) NOT NULL,
  `imagen` varchar(255) NOT NULL,
  `banco_id` int(11) NOT NULL,
  `detalle_gasto_id` int(11) NOT NULL,
  PRIMARY KEY (`banco_id`,`detalle_gasto_id`),
  UNIQUE KEY `referencia` (`referencia`),
  KEY `egresos_bancarios_ibfk_1` (`detalle_gasto_id`),
  CONSTRAINT `egresos_bancarios_ibfk_1` FOREIGN KEY (`detalle_gasto_id`) REFERENCES `detalles_gastos` (`id_detalle_gasto`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `egresos_bancarios_ibfk_2` FOREIGN KEY (`banco_id`) REFERENCES `bancos` (`id_banco`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `egresos_bancarios`
--

LOCK TABLES `egresos_bancarios` WRITE;
/*!40000 ALTER TABLE `egresos_bancarios` DISABLE KEYS */;
/*!40000 ALTER TABLE `egresos_bancarios` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gastos`
--

DROP TABLE IF EXISTS `gastos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gastos` (
  `id_gasto` int(11) NOT NULL AUTO_INCREMENT,
  `clasificacion` varchar(20) NOT NULL,
  `tasa_dolar` decimal(15,2) NOT NULL DEFAULT 1.00,
  `tipo_gasto_id` int(11) NOT NULL,
  `solicitud_id` int(11) DEFAULT NULL,
  `proveedor_id` int(11) NOT NULL,
  `descripcion_gasto` text NOT NULL DEFAULT 'Sin descripción',
  `activo` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id_gasto`),
  KEY `proveedor_id` (`proveedor_id`),
  KEY `tipo_gasto_id` (`tipo_gasto_id`),
  KEY `solicitud_id` (`solicitud_id`),
  CONSTRAINT `gastos_ibfk_1` FOREIGN KEY (`proveedor_id`) REFERENCES `proveedores` (`id_proveedor`) ON UPDATE CASCADE,
  CONSTRAINT `gastos_ibfk_2` FOREIGN KEY (`tipo_gasto_id`) REFERENCES `tipo_gasto` (`id_tipo_gasto`) ON UPDATE CASCADE,
  CONSTRAINT `gastos_ibfk_3` FOREIGN KEY (`solicitud_id`) REFERENCES `solicitudes_gasto` (`id_solicitud`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=223 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gastos`
--

LOCK TABLES `gastos` WRITE;
/*!40000 ALTER TABLE `gastos` DISABLE KEYS */;
/*!40000 ALTER TABLE `gastos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `habitantes`
--

DROP TABLE IF EXISTS `habitantes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `habitantes` (
  `id_habitante` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(50) NOT NULL,
  `apellido` varchar(50) NOT NULL,
  `cedula` varchar(15) NOT NULL,
  `telefono` varchar(20) NOT NULL,
  `correo` varchar(100) NOT NULL,
  `fecha_nacimiento` date NOT NULL,
  `sexo` varchar(10) NOT NULL,
  `activo` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id_habitante`) USING BTREE,
  UNIQUE KEY `cedula` (`cedula`),
  UNIQUE KEY `correo` (`correo`)
) ENGINE=InnoDB AUTO_INCREMENT=55 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `habitantes`
--

LOCK TABLES `habitantes` WRITE;
/*!40000 ALTER TABLE `habitantes` DISABLE KEYS */;
/*!40000 ALTER TABLE `habitantes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `habitantes_apartamentos`
--

DROP TABLE IF EXISTS `habitantes_apartamentos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `habitantes_apartamentos` (
  `apartamento_id` int(11) NOT NULL,
  `habitante_id` int(11) NOT NULL,
  `tipo_vinculo` varchar(20) NOT NULL,
  PRIMARY KEY (`apartamento_id`,`habitante_id`),
  KEY `habitantes_apartamentos_ibfk_2` (`habitante_id`),
  CONSTRAINT `habitantes_apartamentos_ibfk_1` FOREIGN KEY (`apartamento_id`) REFERENCES `apartamentos` (`id_apartamento`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `habitantes_apartamentos_ibfk_2` FOREIGN KEY (`habitante_id`) REFERENCES `habitantes` (`id_habitante`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `habitantes_apartamentos`
--

LOCK TABLES `habitantes_apartamentos` WRITE;
/*!40000 ALTER TABLE `habitantes_apartamentos` DISABLE KEYS */;
/*!40000 ALTER TABLE `habitantes_apartamentos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ingresos_bancarios`
--

DROP TABLE IF EXISTS `ingresos_bancarios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ingresos_bancarios` (
  `referencia` varchar(20) NOT NULL,
  `imagen` varchar(255) NOT NULL,
  `banco_id` int(11) NOT NULL,
  `detalle_pago_id` int(11) NOT NULL,
  PRIMARY KEY (`banco_id`,`detalle_pago_id`),
  UNIQUE KEY `referencia` (`referencia`),
  KEY `ingresos_bancarios_ibfk_1` (`detalle_pago_id`),
  CONSTRAINT `ingresos_bancarios_ibfk_1` FOREIGN KEY (`detalle_pago_id`) REFERENCES `detalles_pagos` (`id_detalle_pago`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `ingresos_bancarios_ibfk_2` FOREIGN KEY (`banco_id`) REFERENCES `bancos` (`id_banco`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ingresos_bancarios`
--

LOCK TABLES `ingresos_bancarios` WRITE;
/*!40000 ALTER TABLE `ingresos_bancarios` DISABLE KEYS */;
/*!40000 ALTER TABLE `ingresos_bancarios` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mensualidad`
--

DROP TABLE IF EXISTS `mensualidad`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mensualidad` (
  `id_mensualidad` int(11) NOT NULL AUTO_INCREMENT,
  `periodo_id` int(11) NOT NULL,
  `monto` decimal(15,2) NOT NULL,
  `apartamento_id` int(11) NOT NULL,
  `porcentaje_interes` decimal(5,2) NOT NULL DEFAULT 10.00,
  `limite_mensualidad` tinyint(2) NOT NULL DEFAULT 15,
  `activo` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id_mensualidad`),
  UNIQUE KEY `periodo_apartamento_unico` (`periodo_id`,`apartamento_id`),
  KEY `apartamento_id` (`apartamento_id`),
  KEY `mensualidad_ibfk_periodo` (`periodo_id`),
  CONSTRAINT `mensualidad_ibfk_1` FOREIGN KEY (`apartamento_id`) REFERENCES `apartamentos` (`id_apartamento`) ON UPDATE CASCADE,
  CONSTRAINT `mensualidad_ibfk_periodo` FOREIGN KEY (`periodo_id`) REFERENCES `periodos_mensualidad` (`id_periodo`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=838 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mensualidad`
--

LOCK TABLES `mensualidad` WRITE;
/*!40000 ALTER TABLE `mensualidad` DISABLE KEYS */;
INSERT INTO `mensualidad` VALUES (806,16,59.40,30,10.00,15,0),(807,16,2.70,32,10.00,15,0),(808,16,82.80,31,10.00,15,0),(809,16,13.50,35,10.00,15,0),(810,16,2.70,39,10.00,15,0),(811,16,18.00,37,10.00,15,0),(812,16,18.00,41,10.00,15,0),(813,16,14.17,42,10.00,15,0);
/*!40000 ALTER TABLE `mensualidad` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_VALUE_ON_ZERO' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 /*!50003 TRIGGER `tr_validar_montos_mensualidad_registrar` BEFORE INSERT ON `mensualidad` FOR EACH ROW BEGIN




    IF NEW.monto < 0 THEN




        SIGNAL SQLSTATE '45000'




        SET MESSAGE_TEXT = 'Error Crítico de BD: No se permiten montos negativos en Mensualidades.';




    END IF;




END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_VALUE_ON_ZERO' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 /*!50003 TRIGGER `tr_validar_montos_mensualidad_editar` BEFORE UPDATE ON `mensualidad` FOR EACH ROW BEGIN




    IF NEW.monto < 0 THEN




        SIGNAL SQLSTATE '45000'




        SET MESSAGE_TEXT = 'Error Crítico de BD: No se permiten montos negativos en Mensualidades.';




    END IF;




END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `movimientos_caja`
--

DROP TABLE IF EXISTS `movimientos_caja`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `movimientos_caja` (
  `id_movimiento_caja` int(11) NOT NULL AUTO_INCREMENT,
  `concepto` varchar(100) NOT NULL,
  `monto` decimal(15,2) NOT NULL,
  `tasa_dolar` decimal(15,2) NOT NULL DEFAULT 1.00,
  `fecha` date NOT NULL,
  `estado` varchar(30) NOT NULL,
  `caja_chica_id` int(11) NOT NULL,
  `activo` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id_movimiento_caja`),
  KEY `caja_chica_id` (`caja_chica_id`),
  CONSTRAINT `movimientos_caja_ibfk_1` FOREIGN KEY (`caja_chica_id`) REFERENCES `caja_chica` (`id_caja_chica`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=58 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `movimientos_caja`
--

LOCK TABLES `movimientos_caja` WRITE;
/*!40000 ALTER TABLE `movimientos_caja` DISABLE KEYS */;
/*!40000 ALTER TABLE `movimientos_caja` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pagos`
--

DROP TABLE IF EXISTS `pagos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pagos` (
  `id_pago` int(11) NOT NULL AUTO_INCREMENT,
  `estado` varchar(20) NOT NULL,
  `tasa_dolar` decimal(15,2) NOT NULL DEFAULT 1.00,
  `observacion` text NOT NULL DEFAULT 'Sin observación',
  `activo` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id_pago`)
) ENGINE=InnoDB AUTO_INCREMENT=172 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pagos`
--

LOCK TABLES `pagos` WRITE;
/*!40000 ALTER TABLE `pagos` DISABLE KEYS */;
INSERT INTO `pagos` VALUES (170,'ANULADO',607.39,'pago',0),(171,'ANULADO',607.39,'pago',0);
/*!40000 ALTER TABLE `pagos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pagos_mensualidad`
--

DROP TABLE IF EXISTS `pagos_mensualidad`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pagos_mensualidad` (
  `pago_id` int(11) NOT NULL,
  `mensualidad_id` int(11) NOT NULL,
  `monto_abonado` decimal(15,2) NOT NULL,
  PRIMARY KEY (`pago_id`,`mensualidad_id`),
  KEY `pagos_mensualidad_ibfk_2` (`mensualidad_id`),
  CONSTRAINT `pagos_mensualidad_ibfk_2` FOREIGN KEY (`mensualidad_id`) REFERENCES `mensualidad` (`id_mensualidad`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `pagos_mensualidad_ibfk_pago_maestro` FOREIGN KEY (`pago_id`) REFERENCES `pagos` (`id_pago`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pagos_mensualidad`
--

LOCK TABLES `pagos_mensualidad` WRITE;
/*!40000 ALTER TABLE `pagos_mensualidad` DISABLE KEYS */;
INSERT INTO `pagos_mensualidad` VALUES (170,806,10.00),(171,806,10.00);
/*!40000 ALTER TABLE `pagos_mensualidad` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `periodos_mensualidad`
--

DROP TABLE IF EXISTS `periodos_mensualidad`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `periodos_mensualidad` (
  `id_periodo` int(11) NOT NULL AUTO_INCREMENT,
  `mes` varchar(2) NOT NULL,
  `anio` varchar(4) NOT NULL,
  `tasa_dolar` decimal(15,2) NOT NULL,
  `activo` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id_periodo`),
  UNIQUE KEY `periodo_unico` (`mes`,`anio`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `periodos_mensualidad`
--

LOCK TABLES `periodos_mensualidad` WRITE;
/*!40000 ALTER TABLE `periodos_mensualidad` DISABLE KEYS */;
INSERT INTO `periodos_mensualidad` VALUES (16,'5','2026',607.39,0);
/*!40000 ALTER TABLE `periodos_mensualidad` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `presupuesto`
--

DROP TABLE IF EXISTS `presupuesto`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `presupuesto` (
  `id_presupuesto` int(11) NOT NULL AUTO_INCREMENT,
  `fecha` date NOT NULL,
  `cuota_reserva` decimal(15,2) NOT NULL,
  `tasa_dolar` decimal(15,2) NOT NULL DEFAULT 1.00,
  `observacion` text NOT NULL DEFAULT 'Sin observación',
  `activo` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id_presupuesto`)
) ENGINE=InnoDB AUTO_INCREMENT=115 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `presupuesto`
--

LOCK TABLES `presupuesto` WRITE;
/*!40000 ALTER TABLE `presupuesto` DISABLE KEYS */;
INSERT INTO `presupuesto` VALUES (106,'2026-01-01',10.00,1.00,'enero 2026',0),(107,'2026-02-01',230.00,1.00,'febrero 2026 editado',0),(110,'2026-03-01',234.00,1.00,'Sin observación',0),(111,'2026-04-01',10.00,1.00,'presupuesto abril',0),(112,'2026-05-01',10.00,1.00,'presupuesto mayo',0),(113,'2026-02-01',10.00,607.39,'Sin observación',0),(114,'2026-05-01',10.00,607.39,'Sin observación',0);
/*!40000 ALTER TABLE `presupuesto` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `presupuesto_mensualidad`
--

DROP TABLE IF EXISTS `presupuesto_mensualidad`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `presupuesto_mensualidad` (
  `detalle_presupuesto_id` int(11) NOT NULL,
  `mensualidad_id` int(11) NOT NULL,
  PRIMARY KEY (`detalle_presupuesto_id`,`mensualidad_id`),
  KEY `presupuesto_mensualidad_ibfk_2` (`mensualidad_id`),
  CONSTRAINT `presupuesto_mensualidad_ibfk_1` FOREIGN KEY (`detalle_presupuesto_id`) REFERENCES `detalles_presupuesto` (`id_detalle_presupuesto`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `presupuesto_mensualidad_ibfk_2` FOREIGN KEY (`mensualidad_id`) REFERENCES `mensualidad` (`id_mensualidad`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `presupuesto_mensualidad`
--

LOCK TABLES `presupuesto_mensualidad` WRITE;
/*!40000 ALTER TABLE `presupuesto_mensualidad` DISABLE KEYS */;
INSERT INTO `presupuesto_mensualidad` VALUES (1447,806),(1447,807),(1447,808),(1447,809),(1447,810),(1447,811),(1447,812),(1447,813),(1448,808),(1448,811),(1448,812),(1451,806),(1451,807),(1451,808),(1451,809),(1451,810),(1451,811),(1451,812),(1451,813),(1452,806),(1452,807),(1452,808),(1452,809),(1452,810),(1452,811),(1452,812),(1452,813);
/*!40000 ALTER TABLE `presupuesto_mensualidad` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `proveedores`
--

DROP TABLE IF EXISTS `proveedores`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `proveedores` (
  `id_proveedor` int(11) NOT NULL AUTO_INCREMENT,
  `nombre_proveedor` varchar(50) NOT NULL,
  `servicio` varchar(50) NOT NULL,
  `rif` varchar(20) NOT NULL,
  `direccion` text NOT NULL,
  `activo` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id_proveedor`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `proveedores`
--

LOCK TABLES `proveedores` WRITE;
/*!40000 ALTER TABLE `proveedores` DISABLE KEYS */;
INSERT INTO `proveedores` VALUES (1,'Administración (Caja Chica)','Reposición de Caja','J0000000','Oficina Administrativa',1),(2,'Corpoelec','Luz','V3434523','Lara avenida',1),(3,'Jardinero','Trabajos en jardineria','E13123343','terminal',1),(4,'Reparaciones CA','Reparara','V2342344','Zona industrial',1),(5,'Gas Lara','Gas','V2352345','Lara',1);
/*!40000 ALTER TABLE `proveedores` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reposiciones`
--

DROP TABLE IF EXISTS `reposiciones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `reposiciones` (
  `gasto_id` int(11) NOT NULL,
  `movimiento_caja_id` int(11) NOT NULL,
  PRIMARY KEY (`gasto_id`,`movimiento_caja_id`),
  KEY `reposiciones_ibfk_2` (`movimiento_caja_id`),
  CONSTRAINT `reposiciones_ibfk_1` FOREIGN KEY (`gasto_id`) REFERENCES `gastos` (`id_gasto`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `reposiciones_ibfk_2` FOREIGN KEY (`movimiento_caja_id`) REFERENCES `movimientos_caja` (`id_movimiento_caja`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reposiciones`
--

LOCK TABLES `reposiciones` WRITE;
/*!40000 ALTER TABLE `reposiciones` DISABLE KEYS */;
/*!40000 ALTER TABLE `reposiciones` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `solicitudes_gasto`
--

DROP TABLE IF EXISTS `solicitudes_gasto`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `solicitudes_gasto` (
  `id_solicitud` int(11) NOT NULL AUTO_INCREMENT,
  `fecha_reporte` date NOT NULL,
  `descripcion_necesidad` text NOT NULL,
  `nombre_solicitante` varchar(50) NOT NULL,
  `monto_estimado` decimal(15,2) NOT NULL,
  `estado` varchar(20) NOT NULL,
  `presupuesto_id` int(11) NOT NULL,
  `prioridad` varchar(20) NOT NULL,
  `activo` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id_solicitud`),
  KEY `presupuesto_mensual_id` (`presupuesto_id`),
  CONSTRAINT `solicitudes_gasto_ibfk_1` FOREIGN KEY (`presupuesto_id`) REFERENCES `presupuesto` (`id_presupuesto`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `solicitudes_gasto`
--

LOCK TABLES `solicitudes_gasto` WRITE;
/*!40000 ALTER TABLE `solicitudes_gasto` DISABLE KEYS */;
/*!40000 ALTER TABLE `solicitudes_gasto` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tipo_gasto`
--

DROP TABLE IF EXISTS `tipo_gasto`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tipo_gasto` (
  `id_tipo_gasto` int(11) NOT NULL AUTO_INCREMENT,
  `nombre_tipo_gasto` varchar(50) NOT NULL,
  `activo` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id_tipo_gasto`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tipo_gasto`
--

LOCK TABLES `tipo_gasto` WRITE;
/*!40000 ALTER TABLE `tipo_gasto` DISABLE KEYS */;
INSERT INTO `tipo_gasto` VALUES (1,'Reposición de Caja Chica',1),(2,'Servicios Públicos',1),(3,'Personal y Obligaciones Laborales',1),(4,'Mantenimientos y Reparaciones',1),(5,'Servicio de Gas',1),(9,'Suministros de Limpieza y Operacion',1),(10,'Gastos Administrativos y Financieros',1);
/*!40000 ALTER TABLE `tipo_gasto` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `vw_ejecucion_presupuesto`
--

DROP TABLE IF EXISTS `vw_ejecucion_presupuesto`;
/*!50001 DROP VIEW IF EXISTS `vw_ejecucion_presupuesto`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `vw_ejecucion_presupuesto` AS SELECT
 1 AS `id_presupuesto`,
  1 AS `anio_presupuesto`,
  1 AS `descripcion_presupuesto`,
  1 AS `partida`,
  1 AS `monto_presupuestado`,
  1 AS `monto_ejecutado`,
  1 AS `disponible` */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `vw_estado_cuentas_mensualidad`
--

DROP TABLE IF EXISTS `vw_estado_cuentas_mensualidad`;
/*!50001 DROP VIEW IF EXISTS `vw_estado_cuentas_mensualidad`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `vw_estado_cuentas_mensualidad` AS SELECT
 1 AS `id_mensualidad`,
  1 AS `apartamento_id`,
  1 AS `nro_apartamento`,
  1 AS `mes`,
  1 AS `anio`,
  1 AS `monto_cuota`,
  1 AS `total_abonado`,
  1 AS `deuda_pendiente`,
  1 AS `estado_pago` */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `vw_historial_pagos`
--

DROP TABLE IF EXISTS `vw_historial_pagos`;
/*!50001 DROP VIEW IF EXISTS `vw_historial_pagos`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `vw_historial_pagos` AS SELECT
 1 AS `id_pago`,
  1 AS `estado`,
  1 AS `activo`,
  1 AS `ultima_fecha`,
  1 AS `monto_total`,
  1 AS `tipo_pago_predominante`,
  1 AS `apartamento`,
  1 AS `periodos` */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `vw_saldo_caja_chica`
--

DROP TABLE IF EXISTS `vw_saldo_caja_chica`;
/*!50001 DROP VIEW IF EXISTS `vw_saldo_caja_chica`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `vw_saldo_caja_chica` AS SELECT
 1 AS `id_caja_chica`,
  1 AS `estado`,
  1 AS `monto_base`,
  1 AS `total_gastado_pendiente`,
  1 AS `saldo_disponible` */;
SET character_set_client = @saved_cs_client;

--
-- Dumping events for database 'haydee_db'
--

--
-- Dumping routines for database 'haydee_db'
--
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_VALUE_ON_ZERO' */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_gestionar_periodos_automaticos` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
DELIMITER ;;
CREATE PROCEDURE `sp_gestionar_periodos_automaticos`()
BEGIN

    DECLARE v_abiertos INT;

    DECLARE v_ultimo_fondo DECIMAL(15,2) DEFAULT 0;

    DECLARE v_id_anio_activo INT DEFAULT NULL;

    DECLARE v_cajas_abiertas INT;



    DECLARE EXIT HANDLER FOR SQLEXCEPTION

    BEGIN

        ROLLBACK;

        SELECT 'Error crítico al ejecutar los cierres automáticos.' AS mensaje;

    END;



    START TRANSACTION;



    UPDATE anio_fiscal 

    SET estado = 'Cerrada', activo = 0 

    WHERE estado = 'Abierto' AND fecha_cierre < CURDATE() AND activo = 1;



    SELECT COUNT(*) INTO v_abiertos 

    FROM anio_fiscal 

    WHERE estado = 'Abierto' AND activo = 1;



    IF v_abiertos = 0 THEN

        INSERT INTO anio_fiscal (estado, fecha_inicio, fecha_cierre, descripcion, activo)

        VALUES (

            'Abierto', 

            CURDATE(), 

            DATE_ADD(CURDATE(), INTERVAL 1 YEAR), 

            CONCAT('Año fiscal automático ', YEAR(CURDATE())), 

            1

        );

    END IF;



    UPDATE caja_chica

    SET estado = 'Cerrada'

    WHERE estado = 'Abierto'

      AND (

          YEAR(fecha_creacion) < YEAR(CURDATE()) 

          OR 

          (YEAR(fecha_creacion) = YEAR(CURDATE()) AND MONTH(fecha_creacion) < MONTH(CURDATE()))

      );



    SELECT COUNT(*) INTO v_cajas_abiertas 

    FROM caja_chica 

    WHERE estado = 'Abierto' AND activo = 1;



    IF v_cajas_abiertas = 0 THEN

        
        SELECT id_anio_fiscal INTO v_id_anio_activo 

        FROM anio_fiscal 

        WHERE estado = 'Abierto' AND activo = 1 

        LIMIT 1;



        IF v_id_anio_activo IS NOT NULL THEN

            SELECT fondo_fijo INTO v_ultimo_fondo 

            FROM caja_chica 

            ORDER BY id_caja_chica DESC 

            LIMIT 1;



            INSERT INTO caja_chica (fondo_fijo, estado, descripcion, fecha_creacion, anio_fiscal_id, activo)

            VALUES (

                v_ultimo_fondo, 

                'Abierto', 

                CONCAT('Caja chica automática - Mes ', MONTH(CURDATE()), '/', YEAR(CURDATE())), 

                CURDATE(), 

                v_id_anio_activo, 

                1

            );

        END IF;

    END IF;



    COMMIT;

    SELECT 'Periodos (Año Fiscal y Caja Chica) verificados y gestionados correctamente.' AS mensaje;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ZERO_IN_DATE,NO_ZERO_DATE,NO_ENGINE_SUBSTITUTION' */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_registrar_reposicion_caja` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
DELIMITER ;;
CREATE PROCEDURE `sp_registrar_reposicion_caja`(IN `p_monto` DECIMAL(15,2), IN `p_id_caja` INT, IN `p_tasa_dolar` DECIMAL(15,2))
BEGIN

    DECLARE v_total_pendiente DECIMAL(15,2);

    DECLARE v_gasto_id INT;



    DECLARE EXIT HANDLER FOR SQLEXCEPTION

    BEGIN

        ROLLBACK;

        SELECT 'Error crítico al procesar la reposición en la base de datos.' AS mensaje;

    END;



    START TRANSACTION;



    SELECT IFNULL(SUM(monto), 0) INTO v_total_pendiente

    FROM movimientos_caja

    WHERE caja_chica_id = p_id_caja AND estado = 'PENDIENTE' AND activo = 1

    FOR UPDATE;



    IF v_total_pendiente = 0 THEN

        ROLLBACK;

        SELECT 'No hay movimientos pendientes por reponer en esta caja.' AS mensaje;

    ELSE

        INSERT INTO gastos (

            clasificacion, 

            tasa_dolar, 

            tipo_gasto_id, 

            proveedor_id, 

            descripcion_gasto, 

            activo

        ) VALUES (

            'REPOSICION', 

            p_tasa_dolar, 

            1,            
            1,            
            CONCAT('Reposición de Caja Chica - ', DATE_FORMAT(CURDATE(), '%d/%m/%Y')), 

            1

        );



        SET v_gasto_id = LAST_INSERT_ID();



        INSERT INTO reposiciones (gasto_id, movimiento_caja_id)

        SELECT v_gasto_id, id_movimiento_caja

        FROM movimientos_caja

        WHERE caja_chica_id = p_id_caja AND estado = 'PENDIENTE' AND activo = 1;



        UPDATE movimientos_caja

        SET estado = 'REPUESTO'

        WHERE caja_chica_id = p_id_caja AND estado = 'PENDIENTE' AND activo = 1;



        COMMIT;

        SELECT CONCAT('Reposición procesada exitosamente por ', v_total_pendiente, ' Bs. Gasto registrado con Nro: ', v_gasto_id) AS mensaje;

    END IF;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Final view structure for view `vw_ejecucion_presupuesto`
--

/*!50001 DROP VIEW IF EXISTS `vw_ejecucion_presupuesto`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 SQL SECURITY DEFINER */
/*!50001 VIEW `vw_ejecucion_presupuesto` AS select `p`.`id_presupuesto` AS `id_presupuesto`,year(`p`.`fecha`) AS `anio_presupuesto`,`p`.`observacion` AS `descripcion_presupuesto`,`tg`.`nombre_tipo_gasto` AS `partida`,`dp`.`monto` AS `monto_presupuestado`,ifnull((select sum(`dg`.`monto`) from (`gastos` `g` join `detalles_gastos` `dg` on(`g`.`id_gasto` = `dg`.`gasto_id`)) where `g`.`tipo_gasto_id` = `dp`.`tipo_gasto_id` and year(`dg`.`fecha`) = year(`p`.`fecha`) and `g`.`activo` = 1),0) AS `monto_ejecutado`,`dp`.`monto` - ifnull((select sum(`dg`.`monto`) from (`gastos` `g` join `detalles_gastos` `dg` on(`g`.`id_gasto` = `dg`.`gasto_id`)) where `g`.`tipo_gasto_id` = `dp`.`tipo_gasto_id` and year(`dg`.`fecha`) = year(`p`.`fecha`) and `g`.`activo` = 1),0) AS `disponible` from ((`presupuesto` `p` join `detalles_presupuesto` `dp` on(`p`.`id_presupuesto` = `dp`.`presupuesto_id`)) join `tipo_gasto` `tg` on(`dp`.`tipo_gasto_id` = `tg`.`id_tipo_gasto`)) where `p`.`activo` = 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vw_estado_cuentas_mensualidad`
--

/*!50001 DROP VIEW IF EXISTS `vw_estado_cuentas_mensualidad`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 SQL SECURITY DEFINER */
/*!50001 VIEW `vw_estado_cuentas_mensualidad` AS select `m`.`id_mensualidad` AS `id_mensualidad`,`m`.`apartamento_id` AS `apartamento_id`,`a`.`nro_apartamento` AS `nro_apartamento`,`p`.`mes` AS `mes`,`p`.`anio` AS `anio`,`m`.`monto` AS `monto_cuota`,coalesce(`abonos`.`total_abonado`,0) AS `total_abonado`,`m`.`monto` - coalesce(`abonos`.`total_abonado`,0) AS `deuda_pendiente`,case when `m`.`monto` - coalesce(`abonos`.`total_abonado`,0) <= 0 then 'SOLVENTE' else 'PENDIENTE' end AS `estado_pago` from (((`mensualidad` `m` join `apartamentos` `a` on(`m`.`apartamento_id` = `a`.`id_apartamento`)) join `periodos_mensualidad` `p` on(`m`.`periodo_id` = `p`.`id_periodo`)) left join (select `pm`.`mensualidad_id` AS `mensualidad_id`,sum(`pm`.`monto_abonado`) AS `total_abonado` from (`pagos_mensualidad` `pm` join `pagos` `pg` on(`pm`.`pago_id` = `pg`.`id_pago`)) where `pg`.`activo` = 1 and ucase(`pg`.`estado`) = 'PROCESADO' group by `pm`.`mensualidad_id`) `abonos` on(`m`.`id_mensualidad` = `abonos`.`mensualidad_id`)) where `m`.`activo` = 1 and `a`.`activo` = 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vw_historial_pagos`
--

/*!50001 DROP VIEW IF EXISTS `vw_historial_pagos`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 SQL SECURITY DEFINER */
/*!50001 VIEW `vw_historial_pagos` AS select `p`.`id_pago` AS `id_pago`,ucase(`p`.`estado`) AS `estado`,`p`.`activo` AS `activo`,coalesce(max(`dp`.`fecha`),curdate()) AS `ultima_fecha`,sum(coalesce(`dp`.`monto`,0)) AS `monto_total`,substring_index(group_concat(coalesce(`dp`.`tipo_pago`,'No asignado') order by `dp`.`fecha` DESC separator ','),',',1) AS `tipo_pago_predominante`,case when count(distinct `a`.`nro_apartamento`) = 1 then max(`a`.`nro_apartamento`) else 'Varios' end AS `apartamento`,group_concat(distinct concat(`pm_per`.`mes`,'/',`pm_per`.`anio`) separator ', ') AS `periodos` from (((((`pagos` `p` left join `detalles_pagos` `dp` on(`p`.`id_pago` = `dp`.`pago_id`)) left join `pagos_mensualidad` `pm` on(`p`.`id_pago` = `pm`.`pago_id`)) left join `mensualidad` `m` on(`pm`.`mensualidad_id` = `m`.`id_mensualidad`)) left join `periodos_mensualidad` `pm_per` on(`m`.`periodo_id` = `pm_per`.`id_periodo`)) left join `apartamentos` `a` on(`m`.`apartamento_id` = `a`.`id_apartamento`)) where `p`.`activo` = 1 group by `p`.`id_pago` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vw_saldo_caja_chica`
--

/*!50001 DROP VIEW IF EXISTS `vw_saldo_caja_chica`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 SQL SECURITY DEFINER */
/*!50001 VIEW `vw_saldo_caja_chica` AS select `cc`.`id_caja_chica` AS `id_caja_chica`,`cc`.`estado` AS `estado`,`cc`.`fondo_fijo` AS `monto_base`,ifnull((select sum(`mc`.`monto`) from `movimientos_caja` `mc` where `mc`.`caja_chica_id` = `cc`.`id_caja_chica` and `mc`.`activo` = 1 and `mc`.`estado` <> 'Repuesto'),0) AS `total_gastado_pendiente`,`cc`.`fondo_fijo` - ifnull((select sum(`mc`.`monto`) from `movimientos_caja` `mc` where `mc`.`caja_chica_id` = `cc`.`id_caja_chica` and `mc`.`activo` = 1 and `mc`.`estado` <> 'Repuesto'),0) AS `saldo_disponible` from `caja_chica` `cc` where `cc`.`activo` = 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-06-21 18:38:25
