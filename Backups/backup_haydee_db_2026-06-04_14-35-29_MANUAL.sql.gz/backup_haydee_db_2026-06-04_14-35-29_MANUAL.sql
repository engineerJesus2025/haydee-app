-- MariaDB dump 10.19  Distrib 10.4.32-MariaDB, for Win64 (AMD64)
--
-- Host: localhost    Database: haydee_db
-- ------------------------------------------------------
-- Server version	10.4.32-MariaDB-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `anio_fiscal`
--

DROP TABLE IF EXISTS `anio_fiscal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `anio_fiscal` (
  `id_anio_fiscal` int(11) NOT NULL AUTO_INCREMENT,
  `estado` varchar(20) NOT NULL,
  `fecha_inicio` date NOT NULL,
  `fecha_cierre` date NOT NULL,
  `descripcion` text NOT NULL DEFAULT 'Sin descripción',
  `activo` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id_anio_fiscal`)
) ENGINE=InnoDB AUTO_INCREMENT=61 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `anio_fiscal`
--

LOCK TABLES `anio_fiscal` WRITE;
/*!40000 ALTER TABLE `anio_fiscal` DISABLE KEYS */;
INSERT INTO `anio_fiscal` VALUES (47,'Abierto','2026-02-07','2027-02-07','Año fiscal 2026',1),(52,'Cerrada','2026-03-12','2027-03-12','asdas',0),(53,'Cerrada','2026-03-05','2027-03-05','AAA',0),(54,'Cerrada','2026-03-14','2027-03-14','nueva des',0),(55,'Cerrada','2026-03-13','2027-03-13','asda',0),(56,'Cerrada','2026-03-16','2027-03-16','',0),(57,'Cerrada','2026-03-02','2027-03-02','',0),(58,'Cerrada','2026-03-10','2027-03-10','asd',0),(59,'Cerrada','2026-04-07','2027-04-07','pepe',1),(60,'ABIERTO','2026-06-02','2027-06-02','año fiscal de preuba',1);
/*!40000 ALTER TABLE `anio_fiscal` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `apartamentos`
--

DROP TABLE IF EXISTS `apartamentos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `apartamentos` (
  `id_apartamento` int(11) NOT NULL AUTO_INCREMENT,
  `nro_apartamento` varchar(5) NOT NULL,
  `porcentaje_participacion` decimal(5,2) NOT NULL,
  `gas` tinyint(1) NOT NULL,
  `agua` tinyint(1) NOT NULL,
  `alquilado` tinyint(1) NOT NULL,
  `activo` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id_apartamento`)
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `apartamentos`
--

LOCK TABLES `apartamentos` WRITE;
/*!40000 ALTER TABLE `apartamentos` DISABLE KEYS */;
INSERT INTO `apartamentos` VALUES (30,'1-2',22.00,2,1,2,1),(31,'2-3',23.00,1,1,1,1),(32,'2-1',1.00,2,1,1,1),(33,'12',23.00,1,1,1,0),(34,'2-8',2.00,1,2,1,0),(35,'3-1',5.00,2,1,1,1),(36,'2-5',52.00,1,1,1,0),(37,'4-1',5.00,1,1,2,1),(38,'4-2',5.00,1,1,2,0),(39,'3-2',1.00,2,1,1,1),(41,'5-1',5.00,1,1,1,1);
/*!40000 ALTER TABLE `apartamentos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bancos`
--

DROP TABLE IF EXISTS `bancos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bancos` (
  `id_banco` int(11) NOT NULL AUTO_INCREMENT,
  `nombre_banco` varchar(50) NOT NULL,
  `codigo` varchar(7) NOT NULL,
  `numero_cuenta` varchar(50) NOT NULL,
  `tipo_cuenta` varchar(30) NOT NULL,
  `telefono_afiliado` varchar(20) NOT NULL,
  `rif` varchar(30) NOT NULL,
  `activo` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id_banco`),
  UNIQUE KEY `numero_cuenta` (`numero_cuenta`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bancos`
--

LOCK TABLES `bancos` WRITE;
/*!40000 ALTER TABLE `bancos` DISABLE KEYS */;
INSERT INTO `bancos` VALUES (1,'venezuela','0102','0102123412124232323','Ahorro','04152456842','J3232421',1),(6,'Banesco','0117','1242342342424121211','Corriente','04142584985','V5464565',1),(9,'Bancaribe','0114','01140300063000253595','Corriente','04114124142','J305785457',1),(11,'rasdas','1231','2342342342342342323','','21321253213','V2123132',0),(12,'tesoro','1231','425646456456456456','','24243245564','V12345678',0),(13,'Tesoros','0102','2423423423423234234','Corriente','23423423232','V123412321',1),(14,'sdfsdfs','2342','2315646545645656564','','23123153545','V24653215',0),(15,'aASDASD','1234','1231312312312312123','Corriente','12312312323','V231231231',1);
/*!40000 ALTER TABLE `bancos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `caja_chica`
--

DROP TABLE IF EXISTS `caja_chica`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `caja_chica` (
  `id_caja_chica` int(11) NOT NULL AUTO_INCREMENT,
  `fondo_fijo` decimal(15,2) NOT NULL,
  `estado` varchar(20) NOT NULL,
  `descripcion` text NOT NULL DEFAULT 'Sin descripción',
  `fecha_creacion` date NOT NULL DEFAULT current_timestamp(),
  `anio_fiscal_id` int(11) NOT NULL,
  `activo` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id_caja_chica`),
  KEY `anio_fiscal_id` (`anio_fiscal_id`),
  CONSTRAINT `caja_chica_ibfk_1` FOREIGN KEY (`anio_fiscal_id`) REFERENCES `anio_fiscal` (`id_anio_fiscal`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `caja_chica`
--

LOCK TABLES `caja_chica` WRITE;
/*!40000 ALTER TABLE `caja_chica` DISABLE KEYS */;
INSERT INTO `caja_chica` VALUES (24,0.00,'Cerrada','Caja chicas del mes enero - 2026','2026-01-01',47,1),(25,1000.00,'Cerrada','Caja chicas del mes Marzo - 2026','2026-03-09',47,1),(26,1000.00,'Cerrada','Caja chica - 2026','2026-04-02',47,1),(27,1000.00,'Cerrada','Caja chicas del mes Mayo - 2026','2026-05-17',47,1),(28,1000.00,'Abierto','Caja chica automática - Mes 6/2026','2026-06-01',47,1);
/*!40000 ALTER TABLE `caja_chica` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `detalles_gastos`
--

DROP TABLE IF EXISTS `detalles_gastos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `detalles_gastos` (
  `id_detalle_gasto` int(11) NOT NULL AUTO_INCREMENT,
  `fecha` date NOT NULL,
  `monto` decimal(15,2) NOT NULL,
  `metodo_pago` varchar(20) NOT NULL,
  `gasto_id` int(11) NOT NULL,
  PRIMARY KEY (`id_detalle_gasto`),
  KEY `gasto_id` (`gasto_id`),
  CONSTRAINT `detalles_gastos_ibfk_1` FOREIGN KEY (`gasto_id`) REFERENCES `gastos` (`id_gasto`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2057 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `detalles_gastos`
--

LOCK TABLES `detalles_gastos` WRITE;
/*!40000 ALTER TABLE `detalles_gastos` DISABLE KEYS */;
INSERT INTO `detalles_gastos` VALUES (164,'2026-02-03',12.00,'Pago Movil',133),(217,'2026-02-21',12.00,'Efectivo',136),(218,'2026-02-21',900.00,'Efectivo',135),(2001,'2025-12-20',150.00,'Transferencia',201),(2002,'2026-01-15',700.00,'Transferencia',202),(2003,'2026-01-25',1500.00,'Divisa',203),(2004,'2026-02-15',720.00,'Pago Movil',204),(2005,'2026-03-02',300.00,'Efectivo',205),(2006,'2026-03-05',43.00,'Efectivo',206),(2011,'2026-03-08',12312.00,'Efectivo',207),(2012,'2026-03-07',21.00,'Pago Movil',207),(2017,'2026-03-16',910.00,'Efectivo',208),(2018,'2026-02-21',32.00,'Efectivo',134),(2019,'2026-02-06',12.00,'Pago Movil',134),(2020,'2026-03-17',0.00,'Efectivo',209),(2021,'2026-03-17',0.00,'Efectivo',210),(2023,'2026-03-17',15.00,'Efectivo',211),(2024,'2026-03-17',10.00,'Transferencia',211),(2027,'2026-05-21',10.00,'Efectivo',213),(2028,'2026-05-21',10.00,'Transferencia',213),(2047,'2026-05-23',10.00,'Transferencia',212),(2048,'2026-05-26',55.00,'Efectivo',214),(2049,'2026-05-27',30.00,'Transferencia',215),(2050,'2026-05-27',60.00,'Efectivo',216),(2051,'2026-05-28',50.00,'Pago Movil',217),(2052,'2026-06-03',50.00,'Efectivo',218),(2053,'2026-06-03',20.00,'Transferencia',219),(2054,'2026-06-03',20.00,'Efectivo',220),(2055,'2026-06-03',20.00,'Pago Movil',221),(2056,'2026-06-03',25.00,'Efectivo',222);
/*!40000 ALTER TABLE `detalles_gastos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `detalles_pagos`
--

DROP TABLE IF EXISTS `detalles_pagos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `detalles_pagos` (
  `id_detalle_pago` int(11) NOT NULL AUTO_INCREMENT,
  `fecha` date NOT NULL,
  `monto` decimal(15,2) NOT NULL,
  `tipo_pago` varchar(20) NOT NULL,
  `pago_id` int(11) NOT NULL,
  PRIMARY KEY (`id_detalle_pago`),
  KEY `detalles_pagos_ibfk_1` (`pago_id`),
  KEY `idx_pago_fecha` (`pago_id`,`fecha`),
  CONSTRAINT `detalles_pagos_ibfk_1` FOREIGN KEY (`pago_id`) REFERENCES `pagos` (`id_pago`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=1067 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `detalles_pagos`
--

LOCK TABLES `detalles_pagos` WRITE;
/*!40000 ALTER TABLE `detalles_pagos` DISABLE KEYS */;
INSERT INTO `detalles_pagos` VALUES (1026,'2026-05-18',50.00,'Efectivo',135),(1030,'2026-05-18',16.60,'Pago Movil',138),(1031,'2026-05-19',50.00,'Transferencia',139),(1032,'2026-05-20',10.00,'Efectivo',140),(1033,'2026-05-20',10.00,'Efectivo',141),(1034,'2026-05-20',10.00,'Efectivo',142),(1035,'2026-05-20',25.00,'Pago Movil',143),(1036,'2026-05-01',20.00,'Divisa',143),(1041,'2026-05-23',12.00,'Divisa',143),(1055,'2026-05-23',8.00,'Transferencia',143),(1056,'2026-05-26',505.00,'Transferencia',147),(1057,'2026-05-27',20.00,'Transferencia',148),(1058,'2026-06-03',10.00,'Transferencia',149),(1059,'2026-06-03',20.00,'Transferencia',150),(1060,'2026-06-03',12.00,'Transferencia',151),(1061,'2026-06-03',10.00,'Transferencia',152),(1062,'2026-06-03',20.00,'Transferencia',153),(1063,'2026-06-03',10.00,'Transferencia',154),(1064,'2026-06-03',20.00,'Transferencia',155),(1065,'2026-06-03',100.00,'Efectivo',156),(1066,'2026-06-03',100.00,'Efectivo',157);
/*!40000 ALTER TABLE `detalles_pagos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `detalles_presupuesto`
--

DROP TABLE IF EXISTS `detalles_presupuesto`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `detalles_presupuesto` (
  `id_detalle_presupuesto` int(11) NOT NULL AUTO_INCREMENT,
  `monto` decimal(15,2) NOT NULL,
  `nombre_detalle` varchar(50) NOT NULL,
  `presupuesto_id` int(11) NOT NULL,
  `tipo_gasto_id` int(11) NOT NULL,
  PRIMARY KEY (`id_detalle_presupuesto`),
  KEY `presupuesto_id` (`presupuesto_id`),
  KEY `tipo_gasto_id` (`tipo_gasto_id`),
  CONSTRAINT `detalles_presupuesto_ibfk_1` FOREIGN KEY (`presupuesto_id`) REFERENCES `presupuesto` (`id_presupuesto`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `detalles_presupuesto_ibfk_2` FOREIGN KEY (`tipo_gasto_id`) REFERENCES `tipo_gasto` (`id_tipo_gasto`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=1424 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `detalles_presupuesto`
--

LOCK TABLES `detalles_presupuesto` WRITE;
/*!40000 ALTER TABLE `detalles_presupuesto` DISABLE KEYS */;
INSERT INTO `detalles_presupuesto` VALUES (1327,15.00,'CORPOELEC',106,2),(1328,12.00,'HIDROLARA',106,2),(1329,100.00,'Trabajadora Residencial',106,3),(1330,100.00,'Bono de alimentacion',106,3),(1331,100.00,'Bono de ayuda',106,3),(1332,100.00,'Seguridad Social',106,3),(1333,100.00,'Mantenimiento ascensor',106,4),(1334,100.00,'GAS LARA',106,5),(1335,100.00,'Bolsas de Basura',106,9),(1336,100.00,'Productos de Limpieza',106,9),(1337,100.00,'Comisiones Bancarias',106,10),(1338,100.00,'Exencion cuota del administrador',106,10),(1351,23.00,'CORPOELEC',107,2),(1352,15.00,'HIDROLARA',107,2),(1353,233.00,'Trabajadora Residencial',107,3),(1354,12.00,'Bono de alimentacion',107,3),(1355,12.00,'Bono de ayuda',107,3),(1356,100.00,'Seguridad Social',107,3),(1357,12.00,'Mantenimiento ascensor',107,4),(1358,200.00,'GAS LARA',107,5),(1359,20.00,'Bolsas de Basura',107,9),(1360,200.00,'Productos de Limpieza',107,9),(1361,200.00,'Comisiones Bancarias',107,10),(1362,200.00,'Exencion cuota del administrador',107,10),(1387,12.00,'Exencion cuota del administrador',110,10),(1388,10.00,'CORPOELEC',111,2),(1389,5.00,'HIDROLARA',111,2),(1390,123.00,'Trabajadora Residencial',111,3),(1391,15.00,'Bono de alimentacion',111,3),(1392,123.00,'Bono de ayuda',111,3),(1393,15.00,'Seguridad Social',111,3),(1394,12.00,'Mantenimiento ascensor',111,4),(1395,23.00,'GAS LARA',111,5),(1396,51.00,'Bolsas de Basura',111,9),(1397,12.00,'Productos de Limpieza',111,9),(1398,10.00,'Comisiones Bancarias',111,10),(1399,21.00,'Exencion cuota del administrador',111,10),(1412,10.00,'CORPOELEC',112,2),(1413,20.00,'HIDROLARA',112,2),(1414,50.00,'Trabajadora Residencial',112,3),(1415,10.00,'Bono de alimentacion',112,3),(1416,60.00,'Bono de ayuda',112,3),(1417,50.00,'Seguridad Social',112,3),(1418,85.00,'Mantenimiento ascensor',112,4),(1419,78.00,'GAS LARA',112,5),(1420,100.00,'Bolsas de Basura',112,9),(1421,100.00,'Productos de Limpieza',112,9),(1422,100.00,'Comisiones Bancarias',112,10),(1423,100.00,'Exencion cuota del administrador',112,10);
/*!40000 ALTER TABLE `detalles_presupuesto` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `egresos_bancarios`
--

DROP TABLE IF EXISTS `egresos_bancarios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `egresos_bancarios` (
  `referencia` varchar(20) NOT NULL,
  `imagen` varchar(255) NOT NULL,
  `banco_id` int(11) NOT NULL,
  `detalle_gasto_id` int(11) NOT NULL,
  PRIMARY KEY (`banco_id`,`detalle_gasto_id`),
  UNIQUE KEY `referencia` (`referencia`),
  KEY `egresos_bancarios_ibfk_1` (`detalle_gasto_id`),
  CONSTRAINT `egresos_bancarios_ibfk_1` FOREIGN KEY (`detalle_gasto_id`) REFERENCES `detalles_gastos` (`id_detalle_gasto`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `egresos_bancarios_ibfk_2` FOREIGN KEY (`banco_id`) REFERENCES `bancos` (`id_banco`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `egresos_bancarios`
--

LOCK TABLES `egresos_bancarios` WRITE;
/*!40000 ALTER TABLE `egresos_bancarios` DISABLE KEYS */;
INSERT INTO `egresos_bancarios` VALUES ('31231','javascript-logo-javascript-icon-transparent-free-png_1771563760_144.png',1,164),('GASTO-001','',1,2001),('GASTO-002','',1,2002),('GASTO-003','',1,2004),('42321','mensualidad_1779395597_500.PNG',1,2028),('1235412','CSS-Logo_1773003460_864.jpg',6,2012),('412123','mensualidad_1771710356_291.PNG',6,2019),('5858822','955ad5d5-ef40-44a7-8b1a-e3213090e54d_1779922826_345.jpeg',6,2049),('508538466','74df44ed-237d-4196-84eb-ab585842a1ac_1779972265_875.jpeg',6,2051),('266564464','aeaa2ba2-b172-400d-bd3d-1cf7dffe2cae_1780491076_932.png',6,2053),('208569','a65cc271-3c1f-438c-ad40-a44b8dc349f4_1780496404_663.jpeg',6,2055),('543524','images__2__1773805029_187.png',9,2024);
/*!40000 ALTER TABLE `egresos_bancarios` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gastos`
--

DROP TABLE IF EXISTS `gastos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gastos` (
  `id_gasto` int(11) NOT NULL AUTO_INCREMENT,
  `clasificacion` varchar(20) NOT NULL,
  `tasa_dolar` decimal(15,2) NOT NULL DEFAULT 1.00,
  `tipo_gasto_id` int(11) NOT NULL,
  `solicitud_id` int(11) DEFAULT NULL,
  `proveedor_id` int(11) NOT NULL,
  `descripcion_gasto` text NOT NULL DEFAULT 'Sin descripción',
  `activo` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id_gasto`),
  KEY `proveedor_id` (`proveedor_id`),
  KEY `tipo_gasto_id` (`tipo_gasto_id`),
  KEY `solicitud_id` (`solicitud_id`),
  CONSTRAINT `gastos_ibfk_1` FOREIGN KEY (`proveedor_id`) REFERENCES `proveedores` (`id_proveedor`) ON UPDATE CASCADE,
  CONSTRAINT `gastos_ibfk_2` FOREIGN KEY (`tipo_gasto_id`) REFERENCES `tipo_gasto` (`id_tipo_gasto`) ON UPDATE CASCADE,
  CONSTRAINT `gastos_ibfk_3` FOREIGN KEY (`solicitud_id`) REFERENCES `solicitudes_gasto` (`id_solicitud`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=223 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gastos`
--

LOCK TABLES `gastos` WRITE;
/*!40000 ALTER TABLE `gastos` DISABLE KEYS */;
INSERT INTO `gastos` VALUES (133,'fijo',1.00,2,NULL,3,'asdasdasasd',0),(134,'fijo',1.00,2,NULL,3,'22222a2222222224',1),(135,'reposicion',1.00,1,NULL,1,'Reposición de Caja Chica - 22/02/2026',1),(136,'fijo',1.00,2,NULL,3,'wwwwwwwwwwwww',0),(201,'Fijo',1.00,1,NULL,1,'Pago de servicio de agua',0),(202,'Fijo',1.00,2,NULL,1,'Honorarios de vigilancia Enero',0),(203,'Variable',1.00,3,NULL,1,'Reparación de bomba de agua',1),(204,'Fijo',1.00,2,NULL,1,'Honorarios de vigilancia Febrero',1),(205,'Variable',1.00,4,NULL,1,'Compra de artículos de limpieza',1),(206,'fijo',1.00,1,NULL,2,'zzzzzzzzzzzzzzzzz',0),(207,'variable',1.00,2,NULL,3,'prueba de gasto 1',1),(208,'reposicion',1.00,1,NULL,1,'Reposición de Caja Chica - 16/03/2026',1),(209,'reposicion',1.00,1,NULL,1,'Reposición de Caja Chica - 17/03/2026',1),(210,'reposicion',1.00,1,NULL,1,'Reposición de Caja Chica - 17/03/2026',1),(211,'variable',1.00,2,NULL,3,'asdasdasdasd',1),(212,'fijo',1.00,1,NULL,3,'asdasdasdasd',1),(213,'FIJO',523.67,2,15,2,'sssssssssss',1),(214,'FIJO',1.00,2,NULL,4,'Zbsvss',1),(215,'VARIABLE',1.00,2,NULL,2,'Tvybyb',1),(216,'VARIABLE',1.00,2,NULL,2,'Hola',1),(217,'FIJO',1.00,4,NULL,4,'Hola ',1),(218,'VARIABLE',1.00,3,NULL,2,'Hola ',1),(219,'VARIABLE',1.00,2,NULL,2,'Hola buenas ',1),(220,'VARIABLE',1.00,2,NULL,2,'Hola ',1),(221,'VARIABLE',1.00,2,NULL,2,'Hola ',1),(222,'VARIABLE',1.00,2,NULL,2,'Ffff',1);
/*!40000 ALTER TABLE `gastos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `habitantes`
--

DROP TABLE IF EXISTS `habitantes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `habitantes` (
  `id_habitante` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(50) NOT NULL,
  `apellido` varchar(50) NOT NULL,
  `cedula` varchar(15) NOT NULL,
  `telefono` varchar(20) NOT NULL,
  `correo` varchar(100) NOT NULL,
  `fecha_nacimiento` date NOT NULL,
  `sexo` varchar(10) NOT NULL,
  `activo` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id_habitante`) USING BTREE,
  UNIQUE KEY `cedula` (`cedula`),
  UNIQUE KEY `correo` (`correo`)
) ENGINE=InnoDB AUTO_INCREMENT=55 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `habitantes`
--

LOCK TABLES `habitantes` WRITE;
/*!40000 ALTER TABLE `habitantes` DISABLE KEYS */;
INSERT INTO `habitantes` VALUES (43,'pepe','asdasda','E1105510','12312312123','pepe@gmail.com','2000-12-12','Masculino',1),(44,'jesa','asdasd','V15321212','21312312121','asda@asasd.ocm','2000-10-10','Masculino',1),(45,'asdasd','asdasdas','V12012120','23423423434','ASDASD@sfas.com','1980-10-10','Femenino',1),(46,'papap','lalala','V23424234','21312312312','lala@gasmic.com','1950-10-10','Masculino',1),(47,'ssdfsdf','asda','V23432423','23423423423','asdasda@asfas.com','1945-10-10','Femenino',1),(48,'boor','borra','V23423234','23654564321','asd@asd.com','1999-01-01','Masculino',0),(49,'asa','asdasd','V2343121','12313455648','asda@adsd.com','1999-10-10','Masculino',0),(50,'asa','asdasd','V23432121','12313455648','asda@adaassdsd.com','1999-10-10','Masculino',0),(51,'fhfgh','asdasd','V2342342','42342342342','asdasd@asd.com','1999-10-10','Masculino',1),(52,'dasdas','asdasd','E12312313','22342323232','ada@asd.com','2000-10-10','Femenino',0),(54,'Maria','Gomez','V29123456','04141234567','maria@mail.com','1992-02-02','Femenino',1);
/*!40000 ALTER TABLE `habitantes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `habitantes_apartamentos`
--

DROP TABLE IF EXISTS `habitantes_apartamentos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `habitantes_apartamentos` (
  `apartamento_id` int(11) NOT NULL,
  `habitante_id` int(11) NOT NULL,
  `tipo_vinculo` varchar(20) NOT NULL,
  PRIMARY KEY (`apartamento_id`,`habitante_id`),
  KEY `habitantes_apartamentos_ibfk_2` (`habitante_id`),
  CONSTRAINT `habitantes_apartamentos_ibfk_1` FOREIGN KEY (`apartamento_id`) REFERENCES `apartamentos` (`id_apartamento`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `habitantes_apartamentos_ibfk_2` FOREIGN KEY (`habitante_id`) REFERENCES `habitantes` (`id_habitante`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `habitantes_apartamentos`
--

LOCK TABLES `habitantes_apartamentos` WRITE;
/*!40000 ALTER TABLE `habitantes_apartamentos` DISABLE KEYS */;
INSERT INTO `habitantes_apartamentos` VALUES (30,43,'Propietario'),(30,44,'Habitante'),(30,48,'Habitante'),(30,49,'Habitante'),(30,50,'Habitante'),(30,51,'Habitante'),(30,52,'Habitante'),(31,46,'Propietario'),(32,45,'Propietario'),(34,54,'Habitante'),(35,47,'Propietario');
/*!40000 ALTER TABLE `habitantes_apartamentos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ingresos_bancarios`
--

DROP TABLE IF EXISTS `ingresos_bancarios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ingresos_bancarios` (
  `referencia` varchar(20) NOT NULL,
  `imagen` varchar(255) NOT NULL,
  `banco_id` int(11) NOT NULL,
  `detalle_pago_id` int(11) NOT NULL,
  PRIMARY KEY (`banco_id`,`detalle_pago_id`),
  UNIQUE KEY `referencia` (`referencia`),
  KEY `ingresos_bancarios_ibfk_1` (`detalle_pago_id`),
  CONSTRAINT `ingresos_bancarios_ibfk_1` FOREIGN KEY (`detalle_pago_id`) REFERENCES `detalles_pagos` (`id_detalle_pago`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `ingresos_bancarios_ibfk_2` FOREIGN KEY (`banco_id`) REFERENCES `bancos` (`id_banco`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ingresos_bancarios`
--

LOCK TABLES `ingresos_bancarios` WRITE;
/*!40000 ALTER TABLE `ingresos_bancarios` DISABLE KEYS */;
INSERT INTO `ingresos_bancarios` VALUES ('53246','fiabil_1779159711_524.PNG',1,1030),('5865659','43c0a065-a53e-4115-bd8c-004838072d63_1779235146_170.jpeg',1,1031),('4686286','10367e49-f030-4e26-8ac1-c8342ae380b1_1779920771_991.jpeg',1,1057),('3235654','default.png',1,1058),('283833468','default.png',1,1059),('5683758','default.png',1,1060),('268656556','22c76522-3b75-45c1-85a4-e273383b6fef_1780460215_709.jpeg',1,1061),('289676646','95e8b8e8-115a-4a02-a081-461511fc0a5e_1780490946_260.jpeg',1,1062),('20464648','d2a87bcc-ec8a-4ad8-9944-e6c86c314a78_1780494949_475.jpeg',1,1063),('1345312','cog_1779299571_171.PNG',6,1035),('4686858','ff3aa0e1-7886-43ac-b0bc-18e73d4fc263_1779820535_428.jpeg',6,1056),('---------','d8321413-2506-40fa-9d46-c728a2376ae4_1780495132_607.jpeg',6,1064);
/*!40000 ALTER TABLE `ingresos_bancarios` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mensualidad`
--

DROP TABLE IF EXISTS `mensualidad`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mensualidad` (
  `id_mensualidad` int(11) NOT NULL AUTO_INCREMENT,
  `periodo_id` int(11) NOT NULL,
  `monto` decimal(15,2) NOT NULL,
  `apartamento_id` int(11) NOT NULL,
  `porcentaje_interes` decimal(5,2) NOT NULL DEFAULT 10.00,
  `limite_mensualidad` tinyint(2) NOT NULL DEFAULT 15,
  `activo` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id_mensualidad`),
  UNIQUE KEY `periodo_apartamento_unico` (`periodo_id`,`apartamento_id`),
  KEY `apartamento_id` (`apartamento_id`),
  KEY `mensualidad_ibfk_periodo` (`periodo_id`),
  CONSTRAINT `mensualidad_ibfk_1` FOREIGN KEY (`apartamento_id`) REFERENCES `apartamentos` (`id_apartamento`) ON UPDATE CASCADE,
  CONSTRAINT `mensualidad_ibfk_periodo` FOREIGN KEY (`periodo_id`) REFERENCES `periodos_mensualidad` (`id_periodo`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=703 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mensualidad`
--

LOCK TABLES `mensualidad` WRITE;
/*!40000 ALTER TABLE `mensualidad` DISABLE KEYS */;
INSERT INTO `mensualidad` VALUES (663,5,66.00,30,10.00,15,1),(664,5,3.00,32,10.00,15,1),(665,5,92.00,31,10.00,15,1),(666,5,15.00,35,10.00,15,1),(667,5,3.00,39,10.00,15,1),(668,5,20.00,37,10.00,15,1),(669,5,20.00,41,10.00,15,1),(684,7,190.00,30,10.00,15,1),(685,7,177.79,31,10.00,15,1),(686,7,7.73,32,10.00,15,1),(687,7,38.65,35,10.00,15,1),(688,7,38.65,37,10.00,15,1),(689,7,7.73,39,10.00,15,1),(690,7,38.65,41,10.00,15,1);
/*!40000 ALTER TABLE `mensualidad` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_VALUE_ON_ZERO' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 /*!50003 TRIGGER `tr_validar_montos_mensualidad_registrar` BEFORE INSERT ON `mensualidad` FOR EACH ROW BEGIN


    IF NEW.monto < 0 THEN


        SIGNAL SQLSTATE '45000'


        SET MESSAGE_TEXT = 'Error Crítico de BD: No se permiten montos negativos en Mensualidades.';


    END IF;


END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_VALUE_ON_ZERO' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 /*!50003 TRIGGER `tr_validar_montos_mensualidad_editar` BEFORE UPDATE ON `mensualidad` FOR EACH ROW BEGIN


    IF NEW.monto < 0 THEN


        SIGNAL SQLSTATE '45000'


        SET MESSAGE_TEXT = 'Error Crítico de BD: No se permiten montos negativos en Mensualidades.';


    END IF;


END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `movimientos_caja`
--

DROP TABLE IF EXISTS `movimientos_caja`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `movimientos_caja` (
  `id_movimiento_caja` int(11) NOT NULL AUTO_INCREMENT,
  `concepto` varchar(100) NOT NULL,
  `monto` decimal(15,2) NOT NULL,
  `fecha` date NOT NULL,
  `estado` varchar(30) NOT NULL,
  `caja_chica_id` int(11) NOT NULL,
  `activo` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id_movimiento_caja`),
  KEY `caja_chica_id` (`caja_chica_id`),
  CONSTRAINT `movimientos_caja_ibfk_1` FOREIGN KEY (`caja_chica_id`) REFERENCES `caja_chica` (`id_caja_chica`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=58 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `movimientos_caja`
--

LOCK TABLES `movimientos_caja` WRITE;
/*!40000 ALTER TABLE `movimientos_caja` DISABLE KEYS */;
INSERT INTO `movimientos_caja` VALUES (42,'cafe',10.00,'2026-03-09','Repuesto',25,1),(43,'se pagaron 3 bombillos nuevos',900.00,'2026-03-15','Repuesto',25,1),(44,'aaaaa',10.00,'2026-03-16','Pendiente por reposicion',25,0),(57,'Compra de bombillos seguros',50.00,'2026-06-02','Pendiente por reposicion',26,1);
/*!40000 ALTER TABLE `movimientos_caja` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pagos`
--

DROP TABLE IF EXISTS `pagos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pagos` (
  `id_pago` int(11) NOT NULL AUTO_INCREMENT,
  `estado` varchar(20) NOT NULL,
  `tasa_dolar` decimal(15,2) NOT NULL DEFAULT 1.00,
  `observacion` text NOT NULL DEFAULT 'Sin observación',
  `activo` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id_pago`)
) ENGINE=InnoDB AUTO_INCREMENT=158 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pagos`
--

LOCK TABLES `pagos` WRITE;
/*!40000 ALTER TABLE `pagos` DISABLE KEYS */;
INSERT INTO `pagos` VALUES (135,'PROCESADO',530.00,'pago',1),(138,'PROCESADO',1.00,'pago',1),(139,'PROCESADO',1.00,'Pago registrado desde la App',1),(140,'PROCESADO',0.00,'Estado actualizado desde la App Móvil',1),(141,'PROCESADO',0.00,'Estado actualizado desde la App Móvil',1),(142,'RECHAZADO',520.91,'pago',1),(143,'PROCESADO',535.00,'Doble revisi?n ejecutada por T2',1),(144,'PENDIENTE',535.00,'Abono registrado por Transacci?n 2',1),(146,'PENDIENTE',535.00,'Abono registrado por Transacci?n 2',1),(147,'PROCESADO',1.00,'Estado actualizado desde la App Móvil',1),(148,'PROCESADO',1.00,'Estado actualizado desde la App Móvil',1),(149,'PENDIENTE',557.97,'Pago registrado desde la App',1),(150,'RECHAZADO',557.97,'Estado actualizado desde la App Móvil',1),(151,'PENDIENTE',557.97,'Pago registrado desde la App',1),(152,'PENDIENTE',557.97,'Pago registrado desde la App',1),(153,'PENDIENTE',558.64,'Pago registrado desde la App',1),(154,'PENDIENTE',558.64,'Pago registrado desde la App',1),(155,'PROCESADO',558.64,'Estado actualizado desde la App Móvil',1),(156,'PENDIENTE',558.64,'Pago registrado desde la App',1),(157,'RECHAZADO',558.64,'Estado actualizado desde la App Móvil',1);
/*!40000 ALTER TABLE `pagos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pagos_mensualidad`
--

DROP TABLE IF EXISTS `pagos_mensualidad`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pagos_mensualidad` (
  `pago_id` int(11) NOT NULL,
  `mensualidad_id` int(11) NOT NULL,
  `monto_abonado` decimal(15,2) NOT NULL,
  PRIMARY KEY (`pago_id`,`mensualidad_id`),
  KEY `pagos_mensualidad_ibfk_2` (`mensualidad_id`),
  CONSTRAINT `pagos_mensualidad_ibfk_2` FOREIGN KEY (`mensualidad_id`) REFERENCES `mensualidad` (`id_mensualidad`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `pagos_mensualidad_ibfk_pago_maestro` FOREIGN KEY (`pago_id`) REFERENCES `pagos` (`id_pago`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pagos_mensualidad`
--

LOCK TABLES `pagos_mensualidad` WRITE;
/*!40000 ALTER TABLE `pagos_mensualidad` DISABLE KEYS */;
INSERT INTO `pagos_mensualidad` VALUES (135,663,50.00),(138,663,16.60),(139,684,50.00),(139,687,15.00),(140,684,10.00),(141,684,10.00),(142,684,10.00),(143,686,8.50),(144,688,18.65),(146,688,18.65),(147,690,505.00),(148,684,20.00),(149,686,10.00),(150,684,20.00),(151,684,12.00),(152,684,10.00),(153,684,20.00),(154,684,10.00),(155,684,20.00),(156,684,100.00),(157,684,100.00);
/*!40000 ALTER TABLE `pagos_mensualidad` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `periodos_mensualidad`
--

DROP TABLE IF EXISTS `periodos_mensualidad`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `periodos_mensualidad` (
  `id_periodo` int(11) NOT NULL AUTO_INCREMENT,
  `mes` varchar(2) NOT NULL,
  `anio` varchar(4) NOT NULL,
  `tasa_dolar` decimal(15,2) NOT NULL,
  `activo` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id_periodo`),
  UNIQUE KEY `periodo_unico` (`mes`,`anio`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `periodos_mensualidad`
--

LOCK TABLES `periodos_mensualidad` WRITE;
/*!40000 ALTER TABLE `periodos_mensualidad` DISABLE KEYS */;
INSERT INTO `periodos_mensualidad` VALUES (5,'1','2026',515.18,1),(7,'05','2026',515.18,1);
/*!40000 ALTER TABLE `periodos_mensualidad` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `presupuesto`
--

DROP TABLE IF EXISTS `presupuesto`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `presupuesto` (
  `id_presupuesto` int(11) NOT NULL AUTO_INCREMENT,
  `fecha` date NOT NULL,
  `cuota_reserva` decimal(15,2) NOT NULL,
  `tasa_dolar` decimal(15,2) NOT NULL DEFAULT 1.00,
  `observacion` text NOT NULL DEFAULT 'Sin observación',
  `activo` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id_presupuesto`)
) ENGINE=InnoDB AUTO_INCREMENT=113 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `presupuesto`
--

LOCK TABLES `presupuesto` WRITE;
/*!40000 ALTER TABLE `presupuesto` DISABLE KEYS */;
INSERT INTO `presupuesto` VALUES (106,'2026-01-01',10.00,1.00,'enero 2026',1),(107,'2026-02-01',230.00,1.00,'febrero 2026 editado',0),(110,'2026-03-01',234.00,1.00,'Sin observación',1),(111,'2026-04-01',10.00,1.00,'presupuesto abril',1),(112,'2026-05-01',10.00,1.00,'presupuesto mayo',1);
/*!40000 ALTER TABLE `presupuesto` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `presupuesto_mensualidad`
--

DROP TABLE IF EXISTS `presupuesto_mensualidad`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `presupuesto_mensualidad` (
  `detalle_presupuesto_id` int(11) NOT NULL,
  `mensualidad_id` int(11) NOT NULL,
  PRIMARY KEY (`detalle_presupuesto_id`,`mensualidad_id`),
  KEY `presupuesto_mensualidad_ibfk_2` (`mensualidad_id`),
  CONSTRAINT `presupuesto_mensualidad_ibfk_1` FOREIGN KEY (`detalle_presupuesto_id`) REFERENCES `detalles_presupuesto` (`id_detalle_presupuesto`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `presupuesto_mensualidad_ibfk_2` FOREIGN KEY (`mensualidad_id`) REFERENCES `mensualidad` (`id_mensualidad`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `presupuesto_mensualidad`
--

LOCK TABLES `presupuesto_mensualidad` WRITE;
/*!40000 ALTER TABLE `presupuesto_mensualidad` DISABLE KEYS */;
INSERT INTO `presupuesto_mensualidad` VALUES (1328,684),(1333,663),(1333,664),(1333,665),(1333,666),(1333,667),(1333,668),(1333,669),(1334,665),(1334,668),(1334,669),(1337,663),(1337,664),(1337,665),(1337,666),(1337,667),(1337,668),(1337,669),(1338,663),(1338,664),(1338,665),(1338,666),(1338,667),(1338,668),(1338,669),(1412,684),(1412,685),(1412,686),(1412,688),(1412,689),(1412,690),(1413,684),(1413,685),(1413,686),(1413,688),(1413,689),(1413,690),(1414,684),(1414,685),(1414,686),(1414,688),(1414,689),(1414,690),(1415,684),(1415,685),(1415,686),(1415,688),(1415,689),(1415,690),(1416,684),(1416,685),(1416,686),(1416,688),(1416,689),(1416,690),(1417,684),(1417,685),(1417,686),(1417,688),(1417,689),(1417,690),(1418,684),(1418,685),(1418,686),(1418,688),(1418,689),(1418,690),(1419,684),(1419,685),(1419,686),(1419,688),(1419,689),(1419,690),(1420,684),(1420,685),(1420,686),(1420,688),(1420,689),(1420,690),(1421,684),(1421,685),(1421,686),(1421,688),(1421,689),(1421,690),(1422,684),(1422,685),(1422,686),(1422,688),(1422,689),(1422,690),(1423,684),(1423,685),(1423,686),(1423,688),(1423,689),(1423,690);
/*!40000 ALTER TABLE `presupuesto_mensualidad` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `proveedores`
--

DROP TABLE IF EXISTS `proveedores`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `proveedores` (
  `id_proveedor` int(11) NOT NULL AUTO_INCREMENT,
  `nombre_proveedor` varchar(50) NOT NULL,
  `servicio` varchar(50) NOT NULL,
  `rif` varchar(20) NOT NULL,
  `direccion` text NOT NULL,
  `activo` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id_proveedor`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `proveedores`
--

LOCK TABLES `proveedores` WRITE;
/*!40000 ALTER TABLE `proveedores` DISABLE KEYS */;
INSERT INTO `proveedores` VALUES (1,'Administración (Caja Chica)','Reposición de Caja','J0000000','Oficina Administrativa',1),(2,'Proimca','Luz','V3434523','Quibor',1),(3,'Jardinero','Trabajos en jardineria','E13123343','terminal',1),(4,'Reparaciones CA','Reparara','V2342344','Zona industrial',1),(5,'Gas Lara','Gas','V2352345','Lara',1),(14,'pepe','pepes','E1231245','Pepelandia',1);
/*!40000 ALTER TABLE `proveedores` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reposiciones`
--

DROP TABLE IF EXISTS `reposiciones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `reposiciones` (
  `gasto_id` int(11) NOT NULL,
  `movimiento_caja_id` int(11) NOT NULL,
  PRIMARY KEY (`gasto_id`,`movimiento_caja_id`),
  KEY `reposiciones_ibfk_2` (`movimiento_caja_id`),
  CONSTRAINT `reposiciones_ibfk_1` FOREIGN KEY (`gasto_id`) REFERENCES `gastos` (`id_gasto`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `reposiciones_ibfk_2` FOREIGN KEY (`movimiento_caja_id`) REFERENCES `movimientos_caja` (`id_movimiento_caja`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reposiciones`
--

LOCK TABLES `reposiciones` WRITE;
/*!40000 ALTER TABLE `reposiciones` DISABLE KEYS */;
INSERT INTO `reposiciones` VALUES (208,42),(208,43);
/*!40000 ALTER TABLE `reposiciones` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `solicitudes_gasto`
--

DROP TABLE IF EXISTS `solicitudes_gasto`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `solicitudes_gasto` (
  `id_solicitud` int(11) NOT NULL AUTO_INCREMENT,
  `fecha_reporte` date NOT NULL,
  `descripcion_necesidad` text NOT NULL,
  `nombre_solicitante` varchar(50) NOT NULL,
  `monto_estimado` decimal(15,2) NOT NULL,
  `estado` varchar(20) NOT NULL,
  `presupuesto_id` int(11) NOT NULL,
  `prioridad` varchar(20) NOT NULL,
  `activo` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id_solicitud`),
  KEY `presupuesto_mensual_id` (`presupuesto_id`),
  CONSTRAINT `solicitudes_gasto_ibfk_1` FOREIGN KEY (`presupuesto_id`) REFERENCES `presupuesto` (`id_presupuesto`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `solicitudes_gasto`
--

LOCK TABLES `solicitudes_gasto` WRITE;
/*!40000 ALTER TABLE `solicitudes_gasto` DISABLE KEYS */;
INSERT INTO `solicitudes_gasto` VALUES (15,'2026-03-18','asdasdasdas','aasasd',12.00,'Pendiente',106,'2',1),(16,'2026-04-12','ssssss','aaaaa',12.00,'Pendiente',106,'1',1),(17,'2026-04-11','asassss','miguel',10.00,'Pendiente',110,'3',1);
/*!40000 ALTER TABLE `solicitudes_gasto` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tipo_gasto`
--

DROP TABLE IF EXISTS `tipo_gasto`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tipo_gasto` (
  `id_tipo_gasto` int(11) NOT NULL AUTO_INCREMENT,
  `nombre_tipo_gasto` varchar(50) NOT NULL,
  `activo` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id_tipo_gasto`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tipo_gasto`
--

LOCK TABLES `tipo_gasto` WRITE;
/*!40000 ALTER TABLE `tipo_gasto` DISABLE KEYS */;
INSERT INTO `tipo_gasto` VALUES (1,'Reposición de Caja Chica',1),(2,'Servicios Públicos',1),(3,'Personal y Obligaciones Laborales',1),(4,'Mantenimientos y Reparaciones',1),(5,'Servicio de Gas',1),(9,'Suministros de Limpieza y Operacion',1),(10,'Gastos Administrativos y Financieros',1),(14,'random',0),(15,'hola',0),(16,'aaaa',0);
/*!40000 ALTER TABLE `tipo_gasto` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `vw_ejecucion_presupuesto`
--

DROP TABLE IF EXISTS `vw_ejecucion_presupuesto`;
/*!50001 DROP VIEW IF EXISTS `vw_ejecucion_presupuesto`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `vw_ejecucion_presupuesto` AS SELECT
 1 AS `id_presupuesto`,
  1 AS `anio_presupuesto`,
  1 AS `descripcion_presupuesto`,
  1 AS `partida`,
  1 AS `monto_presupuestado`,
  1 AS `monto_ejecutado`,
  1 AS `disponible` */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `vw_estado_cuentas_mensualidad`
--

DROP TABLE IF EXISTS `vw_estado_cuentas_mensualidad`;
/*!50001 DROP VIEW IF EXISTS `vw_estado_cuentas_mensualidad`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `vw_estado_cuentas_mensualidad` AS SELECT
 1 AS `id_mensualidad`,
  1 AS `apartamento_id`,
  1 AS `nro_apartamento`,
  1 AS `mes`,
  1 AS `anio`,
  1 AS `monto_cuota`,
  1 AS `total_abonado`,
  1 AS `deuda_pendiente`,
  1 AS `estado_pago` */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `vw_historial_pagos`
--

DROP TABLE IF EXISTS `vw_historial_pagos`;
/*!50001 DROP VIEW IF EXISTS `vw_historial_pagos`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `vw_historial_pagos` AS SELECT
 1 AS `id_pago`,
  1 AS `estado`,
  1 AS `activo`,
  1 AS `ultima_fecha`,
  1 AS `monto_total`,
  1 AS `tipo_pago_predominante`,
  1 AS `apartamento`,
  1 AS `periodos` */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `vw_saldo_caja_chica`
--

DROP TABLE IF EXISTS `vw_saldo_caja_chica`;
/*!50001 DROP VIEW IF EXISTS `vw_saldo_caja_chica`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `vw_saldo_caja_chica` AS SELECT
 1 AS `id_caja_chica`,
  1 AS `estado`,
  1 AS `monto_base`,
  1 AS `total_gastado_pendiente`,
  1 AS `saldo_disponible` */;
SET character_set_client = @saved_cs_client;

--
-- Dumping events for database 'haydee_db'
--

--
-- Dumping routines for database 'haydee_db'
--
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ZERO_IN_DATE,NO_ZERO_DATE,NO_ENGINE_SUBSTITUTION' */ ;
/*!50003 DROP PROCEDURE IF EXISTS `gestionar_anio_fiscal` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
DELIMITER ;;
CREATE PROCEDURE `gestionar_anio_fiscal`()
BEGIN

    DECLARE v_abiertos INT;



    DECLARE EXIT HANDLER FOR SQLEXCEPTION

    BEGIN

        ROLLBACK;

    END;



    START TRANSACTION;



    

    UPDATE anio_fiscal 

    SET estado = 'Cerrada', activo = 0 

    WHERE estado = 'Abierto' AND fecha_cierre < CURDATE() AND activo = 1;



    

    SELECT COUNT(*) INTO v_abiertos 

    FROM anio_fiscal 

    WHERE estado = 'Abierto' AND activo = 1;



    

    IF v_abiertos = 0 THEN

        INSERT INTO anio_fiscal (estado, fecha_inicio, fecha_cierre, descripcion, activo)

        VALUES (

            'Abierto', 

            CURDATE(), 

            DATE_ADD(CURDATE(), INTERVAL 1 YEAR), 

            CONCAT('Año fiscal automático ', YEAR(CURDATE())), 

            1

        );

    END IF;



    COMMIT;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ZERO_IN_DATE,NO_ZERO_DATE,NO_ENGINE_SUBSTITUTION' */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_gestion_caja_chica_mensual` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
DELIMITER ;;
CREATE PROCEDURE `sp_gestion_caja_chica_mensual`()
BEGIN

    DECLARE v_ultimo_fondo DECIMAL(15,2) DEFAULT 0;

    DECLARE v_id_anio_activo INT DEFAULT NULL;

    DECLARE v_cajas_abiertas INT;



    DECLARE EXIT HANDLER FOR SQLEXCEPTION

    BEGIN

        ROLLBACK;

    END;



    START TRANSACTION;



    

    UPDATE caja_chica

    SET estado = 'Cerrada'

    WHERE estado = 'Abierto'

      AND (

          YEAR(fecha_creacion) < YEAR(CURDATE()) 

          OR 

          (YEAR(fecha_creacion) = YEAR(CURDATE()) AND MONTH(fecha_creacion) < MONTH(CURDATE()))

      );



    

    SELECT COUNT(*) INTO v_cajas_abiertas 

    FROM caja_chica 

    WHERE estado = 'Abierto' AND activo = 1;



    

    IF v_cajas_abiertas = 0 THEN

        

        

        SELECT id_anio_fiscal INTO v_id_anio_activo 

        FROM anio_fiscal 

        WHERE estado = 'Abierto' AND activo = 1 

        LIMIT 1;



        

        IF v_id_anio_activo IS NOT NULL THEN

            

            

            SELECT fondo_fijo INTO v_ultimo_fondo 

            FROM caja_chica 

            ORDER BY id_caja_chica DESC 

            LIMIT 1;



            

            INSERT INTO caja_chica (fondo_fijo, estado, descripcion, fecha_creacion, anio_fiscal_id, activo)

            VALUES (

                v_ultimo_fondo, 

                'Abierto', 

                CONCAT('Caja chica automática - Mes ', MONTH(CURDATE()), '/', YEAR(CURDATE())), 

                CURDATE(), 

                v_id_anio_activo, 

                1

            );

        END IF;

    END IF;



    COMMIT;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ZERO_IN_DATE,NO_ZERO_DATE,NO_ENGINE_SUBSTITUTION' */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_registrar_reposicion_caja` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
DELIMITER ;;
CREATE PROCEDURE `sp_registrar_reposicion_caja`(IN p_monto DECIMAL(15,2), IN p_id_caja INT)
BEGIN

    DECLARE v_total_pendiente DECIMAL(15,2);



    DECLARE EXIT HANDLER FOR SQLEXCEPTION

    BEGIN

        ROLLBACK;

        SELECT 'Error crítico al procesar la reposición en la base de datos.' AS mensaje;

    END;



    START TRANSACTION;



    

    SELECT IFNULL(SUM(monto), 0) INTO v_total_pendiente

    FROM movimientos_caja

    WHERE caja_chica_id = p_id_caja AND estado = 'Pendiente por reposicion' AND activo = 1

    FOR UPDATE;



    IF v_total_pendiente = 0 THEN

        ROLLBACK;

        SELECT 'No hay movimientos pendientes por reponer en esta caja.' AS mensaje;

    ELSE

        

        UPDATE movimientos_caja

        SET estado = 'Repuesto'

        WHERE caja_chica_id = p_id_caja AND estado = 'Pendiente por reposicion' AND activo = 1;



        COMMIT;

        SELECT CONCAT('Reposición procesada exitosamente por ', v_total_pendiente, ' Bs.') AS mensaje;

    END IF;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Final view structure for view `vw_ejecucion_presupuesto`
--

/*!50001 DROP VIEW IF EXISTS `vw_ejecucion_presupuesto`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 SQL SECURITY DEFINER */
/*!50001 VIEW `vw_ejecucion_presupuesto` AS select `p`.`id_presupuesto` AS `id_presupuesto`,year(`p`.`fecha`) AS `anio_presupuesto`,`p`.`observacion` AS `descripcion_presupuesto`,`tg`.`nombre_tipo_gasto` AS `partida`,`dp`.`monto` AS `monto_presupuestado`,ifnull((select sum(`dg`.`monto`) from (`gastos` `g` join `detalles_gastos` `dg` on(`g`.`id_gasto` = `dg`.`gasto_id`)) where `g`.`tipo_gasto_id` = `dp`.`tipo_gasto_id` and year(`dg`.`fecha`) = year(`p`.`fecha`) and `g`.`activo` = 1),0) AS `monto_ejecutado`,`dp`.`monto` - ifnull((select sum(`dg`.`monto`) from (`gastos` `g` join `detalles_gastos` `dg` on(`g`.`id_gasto` = `dg`.`gasto_id`)) where `g`.`tipo_gasto_id` = `dp`.`tipo_gasto_id` and year(`dg`.`fecha`) = year(`p`.`fecha`) and `g`.`activo` = 1),0) AS `disponible` from ((`presupuesto` `p` join `detalles_presupuesto` `dp` on(`p`.`id_presupuesto` = `dp`.`presupuesto_id`)) join `tipo_gasto` `tg` on(`dp`.`tipo_gasto_id` = `tg`.`id_tipo_gasto`)) where `p`.`activo` = 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vw_estado_cuentas_mensualidad`
--

/*!50001 DROP VIEW IF EXISTS `vw_estado_cuentas_mensualidad`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 SQL SECURITY DEFINER */
/*!50001 VIEW `vw_estado_cuentas_mensualidad` AS select `m`.`id_mensualidad` AS `id_mensualidad`,`m`.`apartamento_id` AS `apartamento_id`,`a`.`nro_apartamento` AS `nro_apartamento`,`p`.`mes` AS `mes`,`p`.`anio` AS `anio`,`m`.`monto` AS `monto_cuota`,coalesce(`abonos`.`total_abonado`,0) AS `total_abonado`,`m`.`monto` - coalesce(`abonos`.`total_abonado`,0) AS `deuda_pendiente`,case when `m`.`monto` - coalesce(`abonos`.`total_abonado`,0) <= 0 then 'SOLVENTE' else 'PENDIENTE' end AS `estado_pago` from (((`mensualidad` `m` join `apartamentos` `a` on(`m`.`apartamento_id` = `a`.`id_apartamento`)) join `periodos_mensualidad` `p` on(`m`.`periodo_id` = `p`.`id_periodo`)) left join (select `pm`.`mensualidad_id` AS `mensualidad_id`,sum(`pm`.`monto_abonado`) AS `total_abonado` from (`pagos_mensualidad` `pm` join `pagos` `pg` on(`pm`.`pago_id` = `pg`.`id_pago`)) where `pg`.`activo` = 1 and ucase(`pg`.`estado`) = 'PROCESADO' group by `pm`.`mensualidad_id`) `abonos` on(`m`.`id_mensualidad` = `abonos`.`mensualidad_id`)) where `m`.`activo` = 1 and `a`.`activo` = 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vw_historial_pagos`
--

/*!50001 DROP VIEW IF EXISTS `vw_historial_pagos`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 SQL SECURITY DEFINER */
/*!50001 VIEW `vw_historial_pagos` AS select `p`.`id_pago` AS `id_pago`,ucase(`p`.`estado`) AS `estado`,`p`.`activo` AS `activo`,coalesce(max(`dp`.`fecha`),curdate()) AS `ultima_fecha`,sum(coalesce(`dp`.`monto`,0)) AS `monto_total`,substring_index(group_concat(coalesce(`dp`.`tipo_pago`,'No asignado') order by `dp`.`fecha` DESC separator ','),',',1) AS `tipo_pago_predominante`,case when count(distinct `a`.`nro_apartamento`) = 1 then max(`a`.`nro_apartamento`) else 'Varios' end AS `apartamento`,group_concat(distinct concat(`pm_per`.`mes`,'/',`pm_per`.`anio`) separator ', ') AS `periodos` from (((((`pagos` `p` left join `detalles_pagos` `dp` on(`p`.`id_pago` = `dp`.`pago_id`)) left join `pagos_mensualidad` `pm` on(`p`.`id_pago` = `pm`.`pago_id`)) left join `mensualidad` `m` on(`pm`.`mensualidad_id` = `m`.`id_mensualidad`)) left join `periodos_mensualidad` `pm_per` on(`m`.`periodo_id` = `pm_per`.`id_periodo`)) left join `apartamentos` `a` on(`m`.`apartamento_id` = `a`.`id_apartamento`)) where `p`.`activo` = 1 group by `p`.`id_pago` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vw_saldo_caja_chica`
--

/*!50001 DROP VIEW IF EXISTS `vw_saldo_caja_chica`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 SQL SECURITY DEFINER */
/*!50001 VIEW `vw_saldo_caja_chica` AS select `cc`.`id_caja_chica` AS `id_caja_chica`,`cc`.`estado` AS `estado`,`cc`.`fondo_fijo` AS `monto_base`,ifnull((select sum(`mc`.`monto`) from `movimientos_caja` `mc` where `mc`.`caja_chica_id` = `cc`.`id_caja_chica` and `mc`.`activo` = 1 and `mc`.`estado` <> 'Repuesto'),0) AS `total_gastado_pendiente`,`cc`.`fondo_fijo` - ifnull((select sum(`mc`.`monto`) from `movimientos_caja` `mc` where `mc`.`caja_chica_id` = `cc`.`id_caja_chica` and `mc`.`activo` = 1 and `mc`.`estado` <> 'Repuesto'),0) AS `saldo_disponible` from `caja_chica` `cc` where `cc`.`activo` = 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-06-04  8:35:32
